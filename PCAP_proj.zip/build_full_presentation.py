#!/usr/bin/env python3
"""
build_full_presentation.py
Takes Stencil_MiniProject_Presentation.pptx and integrates all project graphs
and a dedicated Team Member Contribution slide, perfectly styled to match
the presentation's #1D2433 dark navy aesthetic.

Output: Stencil_MiniProject_Presentation_With_Graphs.pptx
"""
import copy
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

BG_COLOR = RGBColor(0x1D, 0x24, 0x33)      # Deep slate navy
TEXT_WHITE = RGBColor(0xFF, 0xFF, 0xFF)    # White
TEXT_CORAL = RGBColor(0xFF, 0xB3, 0x8A)    # Peach/coral accent
TEXT_MUTED = RGBColor(0x9E, 0xAB, 0xC0)    # Light gray/slate
CARD_BG = RGBColor(0x27, 0x30, 0x43)       # Card background
ACCENT_BLUE = RGBColor(0x42, 0x99, 0xE1)   # Tech blue
ACCENT_GREEN = RGBColor(0x48, 0xBB, 0x78)  # Tech green
ACCENT_PURPLE = RGBColor(0x9F, 0x7A, 0xEA) # Tech purple

def set_slide_background(slide):
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = BG_COLOR

def add_header(slide, title_text, category_text="EXPERIMENTAL EVALUATION"):
    # Category tag
    tb_cat = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(9.0), Inches(0.25))
    p_cat = tb_cat.text_frame.paragraphs[0]
    r_cat = p_cat.add_run()
    r_cat.text = category_text.upper()
    r_cat.font.size = Pt(9.5)
    r_cat.font.bold = True
    r_cat.font.color.rgb = TEXT_CORAL
    
    # Title
    tb_title = slide.shapes.add_textbox(Inches(0.5), Inches(0.42), Inches(9.0), Inches(0.55))
    p_title = tb_title.text_frame.paragraphs[0]
    r_title = p_title.add_run()
    r_title.text = title_text
    r_title.font.size = Pt(20)
    r_title.font.bold = True
    r_title.font.color.rgb = TEXT_WHITE

def get_clean_slide(prs):
    layout = prs.slide_layouts[6] if len(prs.slide_layouts) > 6 else prs.slide_layouts[-1]
    slide = prs.slides.add_slide(layout)
    for ph in list(slide.placeholders):
        sp = ph._element
        sp.getparent().remove(sp)
    set_slide_background(slide)
    return slide

def create_slide_with_image(prs, title, category, img_path, subtitle=None, notes=None):
    slide = get_clean_slide(prs)
    add_header(slide, title, category)
    
    # Optional subtitle
    top_offset = 1.05
    if subtitle:
        tb_sub = slide.shapes.add_textbox(Inches(0.5), Inches(0.95), Inches(9.0), Inches(0.3))
        p_sub = tb_sub.text_frame.paragraphs[0]
        r_sub = p_sub.add_run()
        r_sub.text = subtitle
        r_sub.font.size = Pt(11)
        r_sub.font.color.rgb = TEXT_MUTED
        top_offset = 1.25
        
    # Insert image centered
    try:
        slide.shapes.add_picture(img_path, Inches(0.5), Inches(top_offset), Inches(9.0), Inches(3.7))
    except Exception as e:
        print(f"Error adding picture {img_path}: {e}")
        
    # Footer notes
    if notes:
        tb_foot = slide.shapes.add_textbox(Inches(0.5), Inches(5.05), Inches(9.0), Inches(0.4))
        p_foot = tb_foot.text_frame.paragraphs[0]
        r_foot = p_foot.add_run()
        r_foot.text = notes
        r_foot.font.size = Pt(9.5)
        r_foot.font.color.rgb = TEXT_CORAL
        
    return slide

def add_team_contribution_slide(prs):
    slide = get_clean_slide(prs)
    add_header(slide, "Team Member Contributions", "ACADEMIC DEMO EVALUATION")
    
    members = [
        ("Rekulakunta Teja Swaroop", "240905324", ACCENT_BLUE, [
            "Mathematical formulation & 2D heat stencil discretization",
            "Derivation of exact discrete amplification factor G",
            "C++ reference sequential baseline & verification harness",
            "Continuous Fourier mode analytical reference & L2 norm error"
        ]),
        ("Mitul Agrawal", "240905400", ACCENT_GREEN, [
            "OpenMP shared-memory loop parallelization",
            "Evaluation of static vs dynamic thread scheduling policies",
            "Double-buffered grid layout & memory cacheline locality",
            "CPU multi-core strong scaling benchmarks (up to 8 threads)"
        ]),
        ("Veerapaneni Lakshmi Sarayu", "240905368", TEXT_CORAL, [
            "MPI 1D strip domain decomposition & rank distribution",
            "Non-blocking ghost row exchange (MPI_Isend / MPI_Irecv)",
            "Boundary buffer packing and host-staged communication pipeline",
            "Pure MPI strong and weak scaling studies across 1, 2, 4, 8 ranks"
        ]),
        ("Kshitij Verma", "240905522", ACCENT_PURPLE, [
            "CUDA GPU kernels: Naive global memory vs 2D Shared Tiling",
            "Dual CUDA streams for communication-computation latency hiding",
            "3-Tier Hybrid engine: 2 MPI ranks sharing single RTX 3050 GPU",
            "Hardware Roofline analysis & transfer-inclusive timer boundaries"
        ]),
    ]
    
    card_width = 4.35
    card_height = 1.85
    coords = [
        (0.5, 1.15),
        (5.15, 1.15),
        (0.5, 3.25),
        (5.15, 3.25)
    ]
    
    for (name, reg, col, bullets), (x, y) in zip(members, coords):
        # Card shape
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(card_width), Inches(card_height))
        shape.fill.solid()
        shape.fill.fore_color.rgb = CARD_BG
        shape.line.color.rgb = col
        shape.line.width = Pt(1.5)
        
        # Text
        tf = shape.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.15)
        tf.margin_top = Inches(0.12)
        tf.margin_right = Inches(0.15)
        tf.margin_bottom = Inches(0.1)
        
        p0 = tf.paragraphs[0]
        r_name = p0.add_run()
        r_name.text = name + "  "
        r_name.font.size = Pt(12)
        r_name.font.bold = True
        r_name.font.color.rgb = TEXT_WHITE
        
        r_reg = p0.add_run()
        r_reg.text = f"({reg})"
        r_reg.font.size = Pt(10)
        r_reg.font.color.rgb = col
        
        for b in bullets:
            p = tf.add_paragraph()
            p.space_before = Pt(2)
            r_b = p.add_run()
            r_b.text = "•  " + b
            r_b.font.size = Pt(8.5)
            r_b.font.color.rgb = TEXT_MUTED

    # Bottom summary pill
    tb_foot = slide.shapes.add_textbox(Inches(0.5), Inches(5.18), Inches(9.0), Inches(0.35))
    p_foot = tb_foot.text_frame.paragraphs[0]
    p_foot.alignment = PP_ALIGN.CENTER
    r_foot = p_foot.add_run()
    r_foot.text = "Complete three-tier hybrid parallelization demonstrated with all 4 teammates active in design, coding & evaluation."
    r_foot.font.size = Pt(9.5)
    r_foot.font.bold = True
    r_foot.font.color.rgb = TEXT_CORAL

def main():
    prs = Presentation("Stencil_MiniProject_Presentation.pptx")
    print(f"Original presentation loaded: {len(prs.slides)} slides")
    
    # 1. Visual Comparison of all 7 Implementations
    create_slide_with_image(
        prs,
        title="7-Implementation Performance Benchmark",
        category="RESULTS: RUNTIME, SPEEDUP & THROUGHPUT",
        img_path="comparison_7_implementations.png",
        subtitle="Comprehensive evaluation across all 7 paradigms for N = 1024 × 1024, T = 200 iterations (5-run medians)",
        notes="Key takeaway: CUDA Tiled reaches 7.30× speedup (55.6 GFLOP/s); MPI 8 ranks achieves 4.61× speedup (35.1 GFLOP/s)."
    )
    
    # 2. Correctness & Heat Diffusion Evolution
    create_slide_with_image(
        prs,
        title="Physical Solution Snapshots & Numerical Validation",
        category="CORRECTNESS & STABILITY",
        img_path="solution_validation.png",
        subtitle="2D heat diffusion snapshots over physical time and continuous L2-norm error convergence",
        notes="Zero race conditions: Discrete RMS error = 2.996 × 10⁻¹⁶; continuous truncation error strictly bounded by O(h²)."
    )
    
    # 3. Scalability Study (Strong & Weak Scaling)
    create_slide_with_image(
        prs,
        title="Strong & Weak Scaling Characteristics",
        category="PERFORMANCE ANALYSIS",
        img_path="scaling_study.png",
        subtitle="Parallel speedup and efficiency curves for distributed MPI execution",
        notes="Strong scaling reaches 5.00× at 8 ranks; weak scaling drops to 0.335 at 8 ranks due to single-host IPC overhead."
    )
    
    # 4. Roofline Model
    create_slide_with_image(
        prs,
        title="Hardware Roofline Model Analysis",
        category="THEORETICAL BOUNDS",
        img_path="roofline.png",
        subtitle="Low Arithmetic Intensity (AI = 0.167 FLOP/byte) places all stencil variants in the memory-bound regime",
        notes="Because AI = 0.167 << 145 FLOP/byte ridge point, DRAM bandwidth saturates before GPU arithmetic ALUs."
    )
    
    # 5. Communication Overlap Ablation
    create_slide_with_image(
        prs,
        title="Communication–Computation Overlap Ablation",
        category="OPTIMIZATION IMPACT",
        img_path="overlap_ablation.png",
        subtitle="Comparing Blocking MPI vs. Non-Blocking MPI vs. Dual-Stream GPU Overlap",
        notes="Non-blocking MPI_Isend/Irecv with dual CUDA streams yields 38% wall-time reduction over naive blocking halo transfers."
    )
    
    # 6. Team Member Contributions Slide
    add_team_contribution_slide(prs)
    
    out_file = "Stencil_MiniProject_Presentation_With_Graphs.pptx"
    prs.save(out_file)
    print(f"Enhanced presentation saved: {out_file} (Total slides: {len(prs.slides)})")

if __name__ == "__main__":
    main()
