# Hybrid MPI + OpenMP + CUDA Parallelization of Iterative Stencil Computations
# A Scalability and Communication–Computation Overlap Study

> **Full three-tier hybrid implementation** now available: [`stencil_hybrid_cuda.cu`](stencil_hybrid_cuda.cu)

## Overview

This project implements and benchmarks a **2D heat-diffusion stencil solver** (5-point finite-difference) across six parallel programming paradigms:

| Implementation | Technology | Parallelism |
|---|---|---|
| `stencil_sequential` | C++ `-O3` | None (serial baseline) |
| `stencil_openmp` | C++ + OpenMP | Shared-memory threads |
| `stencil_mpi` | C++ + MPI | Distributed-memory processes |
| `stencil_hybrid` | C++ + MPI + OpenMP | Hybrid distributed + shared memory |
| `stencil_cuda` | CUDA C++ (tiled) | GPU SIMT with shared-memory tiling |
| **`stencil_hybrid_cuda`** | **MPI + CUDA + OpenMP** | **Full three-tier: distributed GPU + thread overlap** |

---

## Governing Equation

The 2D heat-diffusion stencil update for grid point (i, j) at time step t+1:

```
u[i,j]^(t+1) = u[i,j]^(t) + (α·Δt / h²) · (u[i+1,j] + u[i-1,j] + u[i,j+1] + u[i,j-1] − 4·u[i,j]^(t))
```

Where:
- **α = 0.01** — thermal diffusivity (m²/s)
- **Δt = 0.1 s** — time step
- **h = 1.0 m** — grid spacing
- **r = α·Δt/h² = 0.001** — stability coefficient (must be ≤ 0.25)

---

## Source Files

| File | Description |
|---|---|
| `stencil_cpu.cpp` | Sequential and OpenMP implementations |
| `stencil_mpi.cpp` | MPI and Hybrid MPI+OpenMP implementations |
| `stencil_cuda.cu` | CUDA naive and shared-memory tiled kernels |
| **`stencil_hybrid_cuda.cu`** | **Full three-tier: MPI + CUDA tiled + OpenMP with dual-stream overlap** |
| `stencil_common.hpp` | Shared data structures and helper functions |
| `stencil_runner.py` | Performance-aware backend selector |
| `stencil_config.json` | Default configuration (N, steps, α, Δt, h) |
| `Stencil_Hybrid_Parallel.ipynb` | Complete Colab notebook (compile + benchmark + plot) |

---

## Compilation Commands

```bash
# Sequential
g++ -std=c++17 -O3 stencil_cpu.cpp -o stencil_sequential

# OpenMP
g++ -std=c++17 -O3 -fopenmp -DUSE_OPENMP stencil_cpu.cpp -o stencil_openmp

# MPI
mpic++ -std=c++17 -O3 stencil_mpi.cpp -o stencil_mpi

# Hybrid MPI + OpenMP
mpic++ -std=c++17 -O3 -fopenmp -DUSE_OPENMP stencil_mpi.cpp -o stencil_hybrid

# CUDA (shared-memory tiled)
nvcc -std=c++17 -O3 stencil_cuda.cu -o stencil_cuda

# ★ Full three-tier Hybrid: MPI + CUDA tiled + OpenMP (dual-stream overlap)
nvcc -std=c++17 -O3 -Xcompiler "-fopenmp" \
     $(mpic++ --showme:compile) \
     $(mpic++ --showme:link) \
     stencil_hybrid_cuda.cu -o stencil_hybrid_cuda

# Alternative (OpenMPI with NVCC driving the link step on Linux):
nvcc -std=c++17 -O3 -Xcompiler "-fopenmp" \
     -I$(mpicc --showme:incdirs | tr ' ' '\n' | head -1) \
     -L$(mpicc --showme:libdirs | tr ' ' '\n' | head -1) \
     -lmpi stencil_hybrid_cuda.cu -o stencil_hybrid_cuda
```

---

## Run Examples

```bash
# Sequential: 512×512 grid, 100 steps
./stencil_sequential 512 100

# OpenMP: 4 threads
OMP_NUM_THREADS=4 ./stencil_openmp 512 100

# MPI: 4 processes
mpirun -np 4 ./stencil_mpi 512 100

# Hybrid MPI+OpenMP: 2 ranks × 2 threads
OMP_NUM_THREADS=2 mpirun -np 2 ./stencil_hybrid 512 100

# CUDA tiled
./stencil_cuda 512 100

# ★ Full three-tier Hybrid: 4 MPI ranks × 4 OMP threads × 1 GPU/rank
OMP_NUM_THREADS=4 mpirun -np 4 ./stencil_hybrid_cuda 512 100 benchmark_runs.csv

# Single-node test (all ranks share one GPU):
OMP_NUM_THREADS=2 mpirun -np 2 ./stencil_hybrid_cuda 1024 100
```

---

## Key Design Choices

### 1. Non-Blocking Halo Exchange (MPI)
The MPI implementation uses `MPI_Isend`/`MPI_Irecv` so that interior rows are
updated **while** boundary data is in transit — achieving communication–computation
overlap as described in the project report.

### 2. Shared-Memory Tiling (CUDA)
Each thread block loads an expanded `(TX+2r) × (TY+2r)` tile into shared memory
before computing the stencil update. This avoids redundant global-memory fetches
for the overlapping halo apron and significantly improves achieved memory bandwidth
utilisation.

### 3. Correctness Validation
Every implementation computes the **L2-norm error** against the closed-form
analytical solution (first Fourier mode):

```
u(x,y,t) ≈ u₀ · sin(π·x/L) · sin(π·y/L) · exp(−2π²·α·t/L²)
```

---

## Performance Metrics

Each run prints key=value pairs (easily parsed by the notebook):
```
implementation=sequential
workers=1
N=512
steps=100
runtime_seconds=2.345678
gflops=0.910234
l2_error=0.012345
```

---

## References

1. Message Passing Interface Forum, "MPI 4.0 Standard," 2021.
2. NVIDIA Corporation, "CUDA C++ Programming Guide," 2024.
3. OpenMP ARB, "OpenMP API 5.2," 2021.
4. Williams, Waterman, Patterson, "Roofline Model," CACM 2009.
5. Gropp et al., "Using Advanced MPI," MIT Press, 2014.
6. Wittmann et al., "Asynchronous MPI for the Masses," arXiv 2013.
