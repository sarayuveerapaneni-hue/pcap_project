/*
 * MPI / Hybrid MPI+OpenMP 1D strip decomposition.
 *
 *   mpicxx -std=c++17 -O3 stencil_mpi.cpp -o stencil_mpi
 *   mpicxx -std=c++17 -O3 -fopenmp -DUSE_OPENMP stencil_mpi.cpp -o stencil_hybrid
 *
 *   mpirun -np 4 ./stencil_mpi N steps repeats csv [blocking|nonblocking] [dump.csv]
 */

#include "stencil_common.hpp"
#include <mpi.h>

struct LocalGrid {
    int local_rows = 0;
    int N = 0;
    std::vector<double> data;
    LocalGrid() = default;
    LocalGrid(int lr, int n, double fill = 0.0)
        : local_rows(lr), N(n), data(static_cast<size_t>(lr + 2) * n, fill) {}
    inline double& at(int i, int j) { return data[static_cast<size_t>(i) * N + j]; }
    inline double at(int i, int j) const { return data[static_cast<size_t>(i) * N + j]; }
    double* row_ptr(int i) { return data.data() + static_cast<size_t>(i) * N; }
    const double* row_ptr(int i) const { return data.data() + static_cast<size_t>(i) * N; }
};

static int row_start(int rank, int size, int N) {
    return rank * (N / size) + std::min(rank, N % size);
}
static int row_count(int rank, int size, int N) {
    return N / size + (rank < N % size ? 1 : 0);
}

static void local_update(const LocalGrid& src, LocalGrid& dst,
                         int li_begin, int li_end, int g_row_start) {
    const int N = src.N;
    const double r = STABILITY_R;
#ifdef USE_OPENMP
    #pragma omp parallel for schedule(runtime)
#endif
    for (int li = li_begin; li < li_end; ++li) {
        const int gi = g_row_start + (li - 1);
        if (gi <= 0 || gi >= N - 1) continue;
        for (int j = 1; j < N - 1; ++j) {
            dst.at(li, j) = src.at(li, j) + r * (
                src.at(li + 1, j) + src.at(li - 1, j) +
                src.at(li, j + 1) + src.at(li, j - 1) -
                4.0 * src.at(li, j)
            );
        }
    }
}

static ErrorStats reduce_errors(const LocalGrid& g, int g_row_start, int steps, int N) {
    const double t = steps * time_step_dt(N);
    double sum_c = 0, sum_d = 0, sum_ref_c = 0, sum_ref_d = 0;
    double max_c = 0, max_d = 0;
    long long count = 0;
    for (int li = 1; li <= g.local_rows; ++li) {
        const int gi = g_row_start + (li - 1);
        if (gi <= 0 || gi >= N - 1) continue;
        for (int j = 1; j < N - 1; ++j) {
            const double u = g.at(li, j);
            const double uc = analytical_continuous(gi, j, N, t);
            const double ud = analytical_discrete(gi, j, N, steps);
            const double dc = u - uc, dd = u - ud;
            sum_c += dc * dc; sum_d += dd * dd;
            sum_ref_c += uc * uc; sum_ref_d += ud * ud;
            max_c = std::max(max_c, std::abs(dc));
            max_d = std::max(max_d, std::abs(dd));
            ++count;
        }
    }
    double buf[6] = {sum_c, sum_d, sum_ref_c, sum_ref_d, max_c, max_d};
    double gbuf[6] = {0};
    MPI_Reduce(&buf[0], &gbuf[0], 4, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&buf[4], &gbuf[4], 2, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    long long gcount = 0;
    MPI_Reduce(&count, &gcount, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    ErrorStats e;
    if (gcount > 0) {
        e.rms_continuous = std::sqrt(gbuf[0] / static_cast<double>(gcount));
        e.rms_discrete = std::sqrt(gbuf[1] / static_cast<double>(gcount));
        e.rel_l2_continuous = std::sqrt(gbuf[0] / std::max(gbuf[2], 1e-300));
        e.rel_l2_discrete = std::sqrt(gbuf[1] / std::max(gbuf[3], 1e-300));
        e.max_abs_continuous = gbuf[4];
        e.max_abs_discrete = gbuf[5];
    }
    return e;
}

static void maybe_dump(const std::string& dump, const LocalGrid& g,
                       int rank, int size, int g_row_start, int N) {
    if (dump.empty()) return;
    std::vector<double> global;
    if (rank == 0) global.assign(static_cast<size_t>(N) * N, 0.0);
    for (int r = 0; r < size; ++r) {
        const int rs = row_start(r, size, N);
        const int rc = row_count(r, size, N);
        if (rank == r) {
            if (r == 0) {
                for (int li = 1; li <= rc; ++li)
                    std::copy(g.row_ptr(li), g.row_ptr(li) + N,
                              global.data() + static_cast<size_t>(rs + li - 1) * N);
            } else {
                MPI_Send(g.row_ptr(1), rc * N, MPI_DOUBLE, 0, 99, MPI_COMM_WORLD);
            }
        } else if (rank == 0) {
            std::vector<double> tmp(static_cast<size_t>(rc) * N);
            MPI_Recv(tmp.data(), rc * N, MPI_DOUBLE, r, 99, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            std::copy(tmp.begin(), tmp.end(),
                      global.data() + static_cast<size_t>(rs) * N);
        }
    }
    if (rank == 0) {
        Grid full(N);
        full.data = std::move(global);
        save_grid_csv(dump, full);
    }
}

int main(int argc, char* argv[]) {
#ifdef USE_OPENMP
    int provided = 0;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);
#else
    MPI_Init(&argc, &argv);
#endif
    int rank = 0, size = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    try {
        require_stable();
        const int N = (argc > 1) ? std::stoi(argv[1]) : DEFAULT_N;
        const int steps = (argc > 2) ? std::stoi(argv[2]) : DEFAULT_STEPS;
        const int repeats = (argc > 3) ? std::stoi(argv[3]) : 1;
        const std::string csv = (argc > 4) ? argv[4] : "results/raw_runs.csv";
        const bool blocking = (argc > 5) && std::string(argv[5]) == "blocking";
        const std::string dump = (argc > 6) ? argv[6] : "";
        if (N < 4 || steps < 1) throw std::runtime_error("bad N/steps");
        if (size > N - 2) throw std::runtime_error("too many ranks");

        const int lr = row_count(rank, size, N);
        const int grs = row_start(rank, size, N);
#ifdef USE_OPENMP
        const std::string impl = blocking ? "hybrid_mpi_openmp_blocking" : "hybrid_mpi_openmp";
        const int local_threads = omp_get_max_threads();
        omp_set_dynamic(0);
#else
        const std::string impl = blocking ? "mpi_blocking" : "mpi";
        const int local_threads = 1;
#endif
        int workers = 0;
        MPI_Allreduce(&local_threads, &workers, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

        const int above = (rank > 0) ? rank - 1 : MPI_PROC_NULL;
        const int below = (rank < size - 1) ? rank + 1 : MPI_PROC_NULL;
        ErrorStats last_err{};
        double last_runtime = 0.0;
        LocalGrid last = LocalGrid(lr, N);

        for (int rep = 0; rep < repeats; ++rep) {
            LocalGrid current(lr, N, 0.0), next(lr, N, 0.0);
            for (int li = 1; li <= lr; ++li) {
                const int gi = grs + (li - 1);
                for (int j = 0; j < N; ++j)
                    current.at(li, j) = (gi == 0 || gi == N - 1 || j == 0 || j == N - 1)
                        ? 0.0 : mode_xy(gi, j, N);
            }
            next = current;

            MPI_Barrier(MPI_COMM_WORLD);
            const double t0 = MPI_Wtime();
            for (int s = 0; s < steps; ++s) {
                MPI_Request reqs[4];
                int nreq = 0;
                if (blocking) {
                    MPI_Sendrecv(current.row_ptr(1), N, MPI_DOUBLE, above, 1,
                                 current.row_ptr(lr + 1), N, MPI_DOUBLE, below, 1,
                                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    MPI_Sendrecv(current.row_ptr(lr), N, MPI_DOUBLE, below, 2,
                                 current.row_ptr(0), N, MPI_DOUBLE, above, 2,
                                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    local_update(current, next, 1, lr + 1, grs);
                } else {
                    MPI_Irecv(current.row_ptr(0), N, MPI_DOUBLE, above, 2, MPI_COMM_WORLD, &reqs[nreq++]);
                    MPI_Isend(current.row_ptr(1), N, MPI_DOUBLE, above, 1, MPI_COMM_WORLD, &reqs[nreq++]);
                    MPI_Irecv(current.row_ptr(lr + 1), N, MPI_DOUBLE, below, 1, MPI_COMM_WORLD, &reqs[nreq++]);
                    MPI_Isend(current.row_ptr(lr), N, MPI_DOUBLE, below, 2, MPI_COMM_WORLD, &reqs[nreq++]);
                    if (lr > 2) local_update(current, next, 2, lr, grs);
                    MPI_Waitall(nreq, reqs, MPI_STATUSES_IGNORE);
                    local_update(current, next, 1, 2, grs);
                    local_update(current, next, lr, lr + 1, grs);
                }
                std::swap(current.data, next.data);
            }
            MPI_Barrier(MPI_COMM_WORLD);
         const double local_runtime = MPI_Wtime() - t0;
             MPI_Allreduce(&local_runtime, &last_runtime, 1,
              MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
            last_err = reduce_errors(current, grs, steps, N);
            last = current;
            if (rank == 0) {
                const double gflops = compute_gflops(N, steps, last_runtime);
                append_benchmark_row(csv, impl, N, steps, workers, rep,
                                     last_runtime, gflops, last_err, 0.0);
            }
        }

        maybe_dump(dump, last, rank, size, grs, N);
        if (rank == 0) {
            print_run(impl, workers, N, steps, last_runtime,
                      compute_gflops(N, steps, last_runtime), last_err, 0.0);
            std::cout << "ranks=" << size << "\nthreads_per_rank=" << local_threads
                      << "\nmpi_mode=" << (blocking ? "blocking" : "nonblocking") << "\n";
        }
        MPI_Finalize();
        return 0;
    } catch (const std::exception& e) {
        if (rank == 0) std::cerr << "Error: " << e.what() << "\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
        return 1;
    }
}
