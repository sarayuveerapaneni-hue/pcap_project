import sys
import os
import pandas as pd
import matplotlib.pyplot as plt

if len(sys.argv) < 5:
    print("Usage: python3 compare.py N steps csv1.csv csv2.csv [csv3.csv ...]")
    sys.exit(1)

N = int(sys.argv[1])
steps = int(sys.argv[2])
files = sys.argv[3:]

frames = []
for filename in files:
    if not os.path.isfile(filename):
        print(f"Missing CSV: {filename}")
        sys.exit(1)
    df = pd.read_csv(filename)
    required = {
        "implementation", "N", "steps", "workers",
        "repeat_index", "runtime_seconds"
    }
    if not required.issubset(df.columns):
        print(f"{filename} is missing columns: {required - set(df.columns)}")
        sys.exit(1)
    frames.append(df)

data = pd.concat(frames, ignore_index=True)
data = data[(data["N"] == N) & (data["steps"] == steps)].copy()

if data.empty:
    print(f"No benchmark rows found for N={N}, steps={steps}")
    sys.exit(1)

data = data[data["runtime_seconds"] > 0]
summary = (
    data.groupby(["implementation", "workers"], as_index=False)
    ["runtime_seconds"].median()
    .rename(columns={"runtime_seconds": "median_seconds"})
)

summary["gflops"] = (
    8 * (N - 2) ** 2 * steps / summary["median_seconds"] / 1e9
)

seq = summary[summary["implementation"] == "sequential"]
if not seq.empty:
    seq_time = seq["median_seconds"].iloc[0]
    summary["speedup_vs_seq"] = seq_time / summary["median_seconds"]
    summary["efficiency_%"] = (
        100 * summary["speedup_vs_seq"] / summary["workers"]
    )
else:
    summary["speedup_vs_seq"] = float("nan")
    summary["efficiency_%"] = float("nan")

summary["speedup_vs_1worker_same_impl"] = float("nan")
for impl in summary["implementation"].unique():
    mask = summary["implementation"] == impl
    baseline = summary.loc[mask].sort_values("workers")
    baseline_time = baseline.iloc[0]["median_seconds"]
    summary.loc[mask, "speedup_vs_1worker_same_impl"] = (
        baseline_time / summary.loc[mask, "median_seconds"]
    )

summary.to_csv("comparison.csv", index=False)

with open("comparison.md", "w") as f:
    f.write(f"# Stencil Performance Comparison\n\n")
    f.write(f"Grid: N={N}, steps={steps}. Times are median runtimes.\n\n")
    f.write(summary.round(4).to_markdown(index=False))
    f.write("\n")

plt.figure(figsize=(10, 5))
labels = summary.apply(
    lambda r: f"{r['implementation']} ({int(r['workers'])} workers)", axis=1
)
plt.bar(labels, summary["median_seconds"])
plt.ylabel("Median runtime (seconds)")
plt.title(f"Stencil runtime: N={N}, steps={steps}")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig("comparison.png", dpi=160)

print(summary.round(4).to_string(index=False))
print("\nCreated comparison.csv, comparison.md and comparison.png")
