# Stencil Performance Comparison

Grid: N=512, steps=200. Times are median runtimes.

| implementation         |   workers |   median_seconds |   gflops |   speedup_vs_seq |   efficiency_% |   speedup_vs_1worker_same_impl |
|:-----------------------|----------:|-----------------:|---------:|-----------------:|---------------:|-------------------------------:|
| cuda_naive             |        14 |           0.0077 |  54.2492 |           5.6075 |        40.0539 |                              1 |
| cuda_tiled             |        14 |           0.0079 |  52.6109 |           5.4382 |        38.8443 |                              1 |
| hybrid_mpi_cuda_openmp |         4 |           0.0834 |   4.9888 |           0.5157 |        12.8919 |                              1 |
| hybrid_mpi_openmp      |         4 |           0.03   |  13.8537 |           1.432  |        35.8002 |                              1 |
| mpi                    |         4 |           0.0204 |  20.3825 |           2.1069 |        52.6716 |                              1 |
| openmp                 |         4 |           0.0333 |  12.5098 |           1.2931 |        32.3272 |                              1 |
| sequential             |         1 |           0.043  |   9.6743 |           1      |       100      |                              1 |
