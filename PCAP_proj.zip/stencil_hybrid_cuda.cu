/*
 * MPI + CUDA tiled + OpenMP host staging (single-node multi-rank shares GPUs).
 *
 * Interior rows run on stream_interior while non-blocking MPI halo exchange
 * proceeds; boundary rows run on stream_boundary after Waitall.
 *
 *   nvcc -std=c++17 -O3 -arch=sm_86 -Xcompiler -fopenmp -DUSE_OPENMP \
 *        -I/usr/lib/x86_64-linux-gnu/openmpi/include \
 *        stencil_hybrid_cuda.cu -lmpi -lgomp -o stencil_hybrid_cuda
 */

#include "stencil_common.hpp"
#include <utility>
#include <mpi.h>
#include <cuda_runtime.h>

constexpr int TX = 16;
constexpr int TY = 16;
constexpr int SR = 1;
#define SMEM_W (TX + 2 * SR)
#define SMEM_H (TY + 2 * SR)

static void cuda_check(cudaError_t err, const char* expr, int line) {
    if (err != cudaSuccess)
        throw std::runtime_error(std::string("CUDA line ") + std::to_string(line)
            + " " + expr + ": " + cudaGetErrorString(err));
}
#define CUDA_CHECK(op) cuda_check((op), #op, __LINE__)

static int row_start_of(int rank, int size, int N) {
    return rank * (N / size) + std::min(rank, N % size);
}
static int row_count_of(int rank, int size, int N) {
    return N / size + (rank < N % size ? 1 : 0);
}

__global__ void stencil_strip_kernel(
    const double* src, double* dst,
    int local_rows, int N, int row_begin, int row_end, int g_row_start, double r
) {
    __shared__ double smem[SMEM_H][SMEM_W];
    const int li = row_begin + static_cast<int>(blockIdx.y) * TY + static_cast<int>(threadIdx.y);
    const int gj = static_cast<int>(blockIdx.x) * TX + static_cast<int>(threadIdx.x);
    const int sj = static_cast<int>(threadIdx.x) + SR;
    const int si = static_cast<int>(threadIdx.y) + SR;
    const int total_rows = local_rows + 2;

    auto load = [&](int r_, int c_) -> double {
        if (r_ < 0 || r_ >= total_rows || c_ < 0 || c_ >= N) return 0.0;
        return src[r_ * N + c_];
    };
    smem[si][sj] = load(li, gj);
    if (threadIdx.x < SR) smem[si][sj - SR] = load(li, gj - SR);
    if (threadIdx.x >= TX - SR) smem[si][sj + SR] = load(li, gj + SR);
    if (threadIdx.y < SR) smem[si - SR][sj] = load(li - SR, gj);
    if (threadIdx.y >= TY - SR) smem[si + SR][sj] = load(li + SR, gj);
    __syncthreads();

    if (li < row_begin || li >= row_end) return;
    if (gj < 1 || gj >= N - 1) return;
    const int gi = g_row_start + (li - 1);
    if (gi <= 0 || gi >= N - 1) return;

    dst[li * N + gj] = smem[si][sj] + r * (
        smem[si + 1][sj] + smem[si - 1][sj] +
        smem[si][sj + 1] + smem[si][sj - 1] - 4.0 * smem[si][sj]
    );
}

static std::pair<dim3, dim3> launch_geom(int row_begin, int row_end, int N) {
    const int rows = std::max(row_end - row_begin, 1);
    return {dim3((N + TX - 1) / TX, (rows + TY - 1) / TY), dim3(TX, TY)};
}

int main(int argc, char* argv[]) {
    int provided = 0;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);
    int rank = 0, size = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    try {
        require_stable();
        const int N = (argc > 1) ? std::stoi(argv[1]) : DEFAULT_N;
        const int steps = (argc > 2) ? std::stoi(argv[2]) : DEFAULT_STEPS;
        const int repeats = (argc > 3) ? std::stoi(argv[3]) : 1;
        const std::string csv = (argc > 4) ? argv[4] : "results/raw_runs.csv";
        if (N < 4 || steps < 1) throw std::runtime_error("bad N/steps");
        if (size > N - 2) throw std::runtime_error("too many ranks");

#ifdef USE_OPENMP
        const int omp_threads = omp_get_max_threads();
        omp_set_dynamic(0);
#else
        const int omp_threads = 1;
#endif

        int ndev = 0;
        CUDA_CHECK(cudaGetDeviceCount(&ndev));
        if (ndev < 1) throw std::runtime_error("No CUDA GPU");
        const int device_id = rank % ndev;
        CUDA_CHECK(cudaSetDevice(device_id));
        cudaDeviceProp prop{};
        CUDA_CHECK(cudaGetDeviceProperties(&prop, device_id));

        const int lr = row_count_of(rank, size, N);
        const int grs = row_start_of(rank, size, N);
        const int buf_rows = lr + 2;
        const size_t bytes = static_cast<size_t>(buf_rows) * N * sizeof(double);

        double *h_local = nullptr, *h_send_top = nullptr, *h_send_bot = nullptr;
        double *h_recv_top = nullptr, *h_recv_bot = nullptr;
        CUDA_CHECK(cudaMallocHost(&h_local, bytes));
        CUDA_CHECK(cudaMallocHost(&h_send_top, N * sizeof(double)));
        CUDA_CHECK(cudaMallocHost(&h_send_bot, N * sizeof(double)));
        CUDA_CHECK(cudaMallocHost(&h_recv_top, N * sizeof(double)));
        CUDA_CHECK(cudaMallocHost(&h_recv_bot, N * sizeof(double)));

        std::fill(h_local, h_local + buf_rows * N, 0.0);
        for (int li = 1; li <= lr; ++li) {
            const int gi = grs + (li - 1);
            for (int j = 0; j < N; ++j) {
                h_local[li * N + j] = (gi == 0 || gi == N - 1 || j == 0 || j == N - 1)
                    ? 0.0 : mode_xy(gi, j, N);
            }
        }

        double *d_src = nullptr, *d_dst = nullptr;
        CUDA_CHECK(cudaMalloc(&d_src, bytes));
        CUDA_CHECK(cudaMalloc(&d_dst, bytes));

        cudaStream_t stream_int, stream_bnd;
        CUDA_CHECK(cudaStreamCreate(&stream_int));
        CUDA_CHECK(cudaStreamCreate(&stream_bnd));

        const int above = (rank > 0) ? rank - 1 : MPI_PROC_NULL;
        const int below = (rank < size - 1) ? rank + 1 : MPI_PROC_NULL;
        const bool has_interior = lr > 2;

        ErrorStats last_err{};
        double last_runtime = 0.0;

        for (int rep = 0; rep < repeats; ++rep) {
            CUDA_CHECK(cudaMemcpy(d_src, h_local, bytes, cudaMemcpyHostToDevice));
            CUDA_CHECK(cudaMemcpy(d_dst, h_local, bytes, cudaMemcpyHostToDevice));

            MPI_Barrier(MPI_COMM_WORLD);
            const double t0 = MPI_Wtime();
            for (int s = 0; s < steps; ++s) {
                CUDA_CHECK(cudaMemcpyAsync(h_send_top, d_src + N, N * sizeof(double),
                                           cudaMemcpyDeviceToHost, stream_int));
                CUDA_CHECK(cudaMemcpyAsync(h_send_bot, d_src + static_cast<size_t>(lr) * N,
                                           N * sizeof(double), cudaMemcpyDeviceToHost, stream_int));
                CUDA_CHECK(cudaStreamSynchronize(stream_int));

                MPI_Request reqs[4];
                int nreq = 0;
                MPI_Irecv(h_recv_top, N, MPI_DOUBLE, above, 11, MPI_COMM_WORLD, &reqs[nreq++]);
                MPI_Isend(h_send_top, N, MPI_DOUBLE, above, 10, MPI_COMM_WORLD, &reqs[nreq++]);
                MPI_Irecv(h_recv_bot, N, MPI_DOUBLE, below, 10, MPI_COMM_WORLD, &reqs[nreq++]);
                MPI_Isend(h_send_bot, N, MPI_DOUBLE, below, 11, MPI_COMM_WORLD, &reqs[nreq++]);

                if (has_interior) {
                    auto [g0, b0] = launch_geom(2, lr, N);
                    stencil_strip_kernel<<<g0, b0, 0, stream_int>>>(
                        d_src, d_dst, lr, N, 2, lr, grs, STABILITY_R);
                    CUDA_CHECK(cudaGetLastError());
                }

                MPI_Waitall(nreq, reqs, MPI_STATUSES_IGNORE);

                CUDA_CHECK(cudaMemcpyAsync(d_src, h_recv_top, N * sizeof(double),
                                           cudaMemcpyHostToDevice, stream_bnd));
                CUDA_CHECK(cudaMemcpyAsync(d_src + static_cast<size_t>(lr + 1) * N,
                                           h_recv_bot, N * sizeof(double),
                                           cudaMemcpyHostToDevice, stream_bnd));

                auto [g1, b1] = launch_geom(1, 2, N);
                stencil_strip_kernel<<<g1, b1, 0, stream_bnd>>>(
                    d_src, d_dst, lr, N, 1, 2, grs, STABILITY_R);
                auto [g2, b2] = launch_geom(lr, lr + 1, N);
                stencil_strip_kernel<<<g2, b2, 0, stream_bnd>>>(
                    d_src, d_dst, lr, N, lr, lr + 1, grs, STABILITY_R);
                CUDA_CHECK(cudaGetLastError());

                CUDA_CHECK(cudaStreamSynchronize(stream_int));
                CUDA_CHECK(cudaStreamSynchronize(stream_bnd));
                std::swap(d_src, d_dst);
            }
            MPI_Barrier(MPI_COMM_WORLD);
            const double local_runtime = MPI_Wtime() - t0;
MPI_Allreduce(&local_runtime, &last_runtime, 1,
              MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
            CUDA_CHECK(cudaMemcpy(h_local, d_src, bytes, cudaMemcpyDeviceToHost));
            double sum_c = 0, sum_d = 0, sum_ref_c = 0, sum_ref_d = 0, max_c = 0, max_d = 0;
            long long count = 0;
            const double tsim = steps * time_step_dt(N);
#ifdef USE_OPENMP
            #pragma omp parallel for reduction(+:sum_c,sum_d,sum_ref_c,sum_ref_d,count) reduction(max:max_c,max_d)
#endif
            for (int li = 1; li <= lr; ++li) {
                const int gi = grs + (li - 1);
                if (gi <= 0 || gi >= N - 1) continue;
                for (int j = 1; j < N - 1; ++j) {
                    const double u = h_local[li * N + j];
                    const double uc = analytical_continuous(gi, j, N, tsim);
                    const double ud = analytical_discrete(gi, j, N, steps);
                    sum_c += (u - uc) * (u - uc);
                    sum_d += (u - ud) * (u - ud);
                    sum_ref_c += uc * uc;
                    sum_ref_d += ud * ud;
                    max_c = std::max(max_c, std::abs(u - uc));
                    max_d = std::max(max_d, std::abs(u - ud));
                    ++count;
                }
            }
            double b4[4] = {sum_c, sum_d, sum_ref_c, sum_ref_d};
            double g4[4] = {0};
            MPI_Reduce(b4, g4, 4, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
            double mx[2] = {max_c, max_d}, gmx[2] = {0};
            MPI_Reduce(mx, gmx, 2, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
            long long gcount = 0;
            MPI_Reduce(&count, &gcount, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
            if (rank == 0 && gcount > 0) {
                last_err.rms_continuous = std::sqrt(g4[0] / static_cast<double>(gcount));
                last_err.rms_discrete = std::sqrt(g4[1] / static_cast<double>(gcount));
                last_err.rel_l2_continuous = std::sqrt(g4[0] / std::max(g4[2], 1e-300));
                last_err.rel_l2_discrete = std::sqrt(g4[1] / std::max(g4[3], 1e-300));
                last_err.max_abs_continuous = gmx[0];
                last_err.max_abs_discrete = gmx[1];
                append_benchmark_row(csv, "hybrid_mpi_cuda_openmp", N, steps,
                                     size * omp_threads, rep, last_runtime,
                                     compute_gflops(N, steps, last_runtime), last_err, 0.0);
            }
        }

        if (rank == 0) {
            print_run("hybrid_mpi_cuda_openmp", size * omp_threads, N, steps, last_runtime,
                      compute_gflops(N, steps, last_runtime), last_err, 0.0);
            std::cout << "ranks=" << size << "\nomp_threads_per_rank=" << omp_threads
                      << "\ngpu_name=" << prop.name << "\nshared_gpu_single_node=1\n";
        }

        CUDA_CHECK(cudaStreamDestroy(stream_int));
        CUDA_CHECK(cudaStreamDestroy(stream_bnd));
        CUDA_CHECK(cudaFree(d_src));
        CUDA_CHECK(cudaFree(d_dst));
        CUDA_CHECK(cudaFreeHost(h_local));
        CUDA_CHECK(cudaFreeHost(h_send_top));
        CUDA_CHECK(cudaFreeHost(h_send_bot));
        CUDA_CHECK(cudaFreeHost(h_recv_top));
        CUDA_CHECK(cudaFreeHost(h_recv_bot));
        MPI_Finalize();
        return 0;
    } catch (const std::exception& e) {
        if (rank == 0) std::cerr << "Error: " << e.what() << "\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
        return 1;
    }
}
