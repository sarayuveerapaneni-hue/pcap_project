/*
 * Sequential / OpenMP 2D heat-diffusion stencil.
 *
 *   g++ -std=c++17 -O3 stencil_cpu.cpp -o stencil_sequential
 *   g++ -std=c++17 -O3 -fopenmp -DUSE_OPENMP stencil_cpu.cpp -o stencil_openmp
 *
 *   ./stencil_sequential N steps repeats csv [dump.csv]
 *   OMP_NUM_THREADS=8 OMP_SCHEDULE=static ./stencil_openmp N steps repeats csv
 */

#include "stencil_common.hpp"

int main(int argc, char* argv[]) {
    try {
        require_stable();
        const int N = (argc > 1) ? std::stoi(argv[1]) : DEFAULT_N;
        const int steps = (argc > 2) ? std::stoi(argv[2]) : DEFAULT_STEPS;
        const int repeats = (argc > 3) ? std::stoi(argv[3]) : 1;
        const std::string csv = (argc > 4) ? argv[4] : "results/raw_runs.csv";
        const std::string dump = (argc > 5) ? argv[5] : "";
        if (N < 4 || steps < 1 || repeats < 1)
            throw std::runtime_error("N>=4, steps>=1, repeats>=1 required");

#ifdef USE_OPENMP
        const std::string impl = "openmp";
        const int workers = omp_get_max_threads();
        omp_set_dynamic(0);
#else
        const std::string impl = "sequential";
        const int workers = 1;
#endif

        Grid last(N);
        double last_runtime = 0.0;
        ErrorStats last_err{};

        for (int rep = 0; rep < repeats; ++rep) {
            Grid current(N), next(N);
            initialise_sine(current);
            initialise_sine(next);

            const auto t0 = std::chrono::steady_clock::now();
            for (int s = 0; s < steps; ++s) {
                stencil_update_rows(current, next, 1, N - 1);
                std::swap(current, next);
            }
            const auto t1 = std::chrono::steady_clock::now();
            last_runtime = std::chrono::duration<double>(t1 - t0).count();
            last_err = compute_errors(current, steps);
            const double gflops = compute_gflops(N, steps, last_runtime);
            append_benchmark_row(csv, impl, N, steps, workers, rep,
                                 last_runtime, gflops, last_err, 0.0);
            last = current;
        }

        const double gflops = compute_gflops(N, steps, last_runtime);
        print_run(impl, workers, N, steps, last_runtime, gflops, last_err, 0.0);
        if (!dump.empty()) save_grid_csv(dump, last);
        return (last_err.max_abs_discrete < 1e-9) ? 0 : 2;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
