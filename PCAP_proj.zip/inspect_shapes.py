from pptx import Presentation

prs = Presentation("Stencil_MiniProject_Presentation.pptx")
for idx in [9, 10, 11, 12, 13]: # slides 10-14
    slide = prs.slides[idx]
    print(f"\n=== SLIDE {idx+1} ===")
    for s_idx, shape in enumerate(slide.shapes):
        t = shape.text_frame.text.replace("\n", " ") if shape.has_text_frame else "[Non-text shape]"
        print(f"Shape {s_idx} ({shape.left.inches:.2f}, {shape.top.inches:.2f}, {shape.width.inches:.2f}, {shape.height.inches:.2f}): {t[:70]}")
