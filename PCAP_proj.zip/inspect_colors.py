from pptx import Presentation

prs = Presentation("Stencil_MiniProject_Presentation.pptx")
slide = prs.slides[0]
print("Background fill type:", slide.background.fill.type if slide.background else "None")
for shape in slide.shapes:
    if shape.has_text_frame:
        for p in shape.text_frame.paragraphs:
            for r in p.runs:
                if r.font.color and r.font.color.rgb:
                    print(f"Font color: {r.font.color.rgb}")
                    break
