#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cuda/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p bin results figures dumps logs
hostname | tee logs/hostname.txt
date -Is | tee logs/date.txt
lscpu | tee logs/lscpu.txt
nproc | tee logs/nproc.txt
g++ --version | tee logs/g++.txt
{ command -v mpicxx && mpicxx --showme:version; } | tee logs/mpi.txt || true
{ command -v nvcc && nvcc --version; } | tee logs/nvcc.txt || true
nvidia-smi | tee logs/nvidia-smi.txt || true
uname -a | tee logs/uname.txt

make cpu
make mpi || echo "MPI build failed" | tee logs/mpi_build_fail.txt
make cuda || echo "CUDA build failed" | tee logs/cuda_build_fail.txt
make hybrid || echo "HYBRID CUDA build failed" | tee logs/hybrid_build_fail.txt

RAW="results/raw_runs.csv"
rm -f "$RAW"
CORR="results/correctness_runs.csv"

N_CORR=64
STEPS_CORR=50
N_PERF=256
STEPS_PERF=200
REPEATS=5

echo "=== correctness dumps N=$N_CORR steps=$STEPS_CORR ==="
./bin/stencil_sequential $N_CORR $STEPS_CORR 1 $CORR dumps/sequential_N${N_CORR}.csv | tee logs/seq_corr.txt

for th in 2 4 8; do
  OMP_NUM_THREADS=$th OMP_SCHEDULE=static OMP_DYNAMIC=false \
    ./bin/stencil_openmp $N_CORR $STEPS_CORR 1 $CORR dumps/openmp${th}_N${N_CORR}.csv | tee logs/omp${th}_corr.txt
done

if [[ -x ./bin/stencil_mpi ]]; then
  for np in 1 2 4; do
    mpirun --oversubscribe -np $np ./bin/stencil_mpi $N_CORR $STEPS_CORR 1 $CORR nonblocking dumps/mpi${np}_N${N_CORR}.csv | tee logs/mpi${np}_corr.txt
    mpirun --oversubscribe -np $np ./bin/stencil_mpi $N_CORR $STEPS_CORR 1 $CORR blocking dumps/mpi${np}b_N${N_CORR}.csv | tee logs/mpi${np}b_corr.txt
  done
fi
if [[ -x ./bin/stencil_hybrid ]]; then
  OMP_NUM_THREADS=2 mpirun --oversubscribe -np 2 ./bin/stencil_hybrid $N_CORR $STEPS_CORR 1 $CORR nonblocking dumps/hybrid_N${N_CORR}.csv | tee logs/hybrid_corr.txt
fi
if [[ -x ./bin/stencil_cuda_naive ]]; then
  ./bin/stencil_cuda_naive $N_CORR $STEPS_CORR 1 $CORR dumps/cuda_naive_N${N_CORR}.csv | tee logs/cuda_naive_corr.txt
fi
if [[ -x ./bin/stencil_cuda ]]; then
  ./bin/stencil_cuda $N_CORR $STEPS_CORR 1 $CORR dumps/cuda_tiled_N${N_CORR}.csv | tee logs/cuda_tiled_corr.txt
fi
if [[ -x ./bin/stencil_hybrid_cuda ]]; then
  OMP_NUM_THREADS=2 mpirun --oversubscribe -np 2 ./bin/stencil_hybrid_cuda $N_CORR $STEPS_CORR 1 $CORR | tee logs/hybrid_cuda_corr.txt || true
fi

echo "=== performance N=$N_PERF steps=$STEPS_PERF repeats=$REPEATS ==="
./bin/stencil_sequential $N_PERF $STEPS_PERF $REPEATS $RAW | tee logs/seq_perf.txt
for th in 1 2 4 8; do
  OMP_NUM_THREADS=$th OMP_SCHEDULE=static OMP_DYNAMIC=false \
    ./bin/stencil_openmp $N_PERF $STEPS_PERF $REPEATS $RAW | tee logs/omp${th}_perf.txt
done
if [[ -x ./bin/stencil_mpi ]]; then
  for np in 1 2 4 8; do
    mpirun --oversubscribe -np $np ./bin/stencil_mpi $N_PERF $STEPS_PERF $REPEATS $RAW nonblocking | tee logs/mpi${np}_perf.txt
    mpirun --oversubscribe -np $np ./bin/stencil_mpi $N_PERF $STEPS_PERF $REPEATS $RAW blocking | tee logs/mpi${np}b_perf.txt
  done
fi
if [[ -x ./bin/stencil_hybrid ]]; then
  OMP_NUM_THREADS=2 mpirun --oversubscribe -np 2 ./bin/stencil_hybrid $N_PERF $STEPS_PERF $REPEATS $RAW nonblocking | tee logs/hybrid_2x2_perf.txt
  OMP_NUM_THREADS=4 mpirun --oversubscribe -np 2 ./bin/stencil_hybrid $N_PERF $STEPS_PERF $REPEATS $RAW nonblocking | tee logs/hybrid_2x4_perf.txt
fi
if [[ -x ./bin/stencil_cuda_naive ]]; then
  ./bin/stencil_cuda_naive $N_PERF $STEPS_PERF $REPEATS $RAW | tee logs/cuda_naive_perf.txt
fi
if [[ -x ./bin/stencil_cuda ]]; then
  ./bin/stencil_cuda $N_PERF $STEPS_PERF $REPEATS $RAW | tee logs/cuda_tiled_perf.txt
fi
if [[ -x ./bin/stencil_hybrid_cuda ]]; then
  OMP_NUM_THREADS=2 mpirun --oversubscribe -np 2 ./bin/stencil_hybrid_cuda $N_PERF $STEPS_PERF $REPEATS $RAW | tee logs/hybrid_cuda_perf.txt || true
fi

echo "=== strong scaling MPI N=256 steps=200 ==="
if [[ -x ./bin/stencil_mpi ]]; then
  for np in 1 2 4 8; do
    mpirun --oversubscribe -np $np ./bin/stencil_mpi 256 200 $REPEATS results/strong_raw.csv nonblocking | tee logs/strong_${np}.txt
  done
fi

echo "=== weak scaling ~64 rows/rank? keep local ~128x256 ==="
# Weak: grow N with ranks so interior points ~ constant per rank. 1D strip: N fixed cols, rows ~ N.
# For 1D row split, per-rank rows ~ N/P. Weak: N scales as P so local rows constant.
# Use N = 128 * P? That changes h and dt. We still report it as weak scaling of the discrete problem.
if [[ -x ./bin/stencil_mpi ]]; then
  mpirun --oversubscribe -np 1 ./bin/stencil_mpi 128 200 $REPEATS results/weak_raw.csv nonblocking | tee logs/weak_1.txt
  mpirun --oversubscribe -np 2 ./bin/stencil_mpi 256 200 $REPEATS results/weak_raw.csv nonblocking | tee logs/weak_2.txt
  mpirun --oversubscribe -np 4 ./bin/stencil_mpi 512 200 $REPEATS results/weak_raw.csv nonblocking | tee logs/weak_4.txt
fi

echo "=== extra N=512 sequential/openmp/cuda if time allows ==="
./bin/stencil_sequential 512 100 3 $RAW | tee logs/seq_512.txt
OMP_NUM_THREADS=8 OMP_SCHEDULE=static OMP_DYNAMIC=false ./bin/stencil_openmp 512 100 3 $RAW | tee logs/omp8_512.txt
if [[ -x ./bin/stencil_cuda ]]; then
  ./bin/stencil_cuda 512 100 3 $RAW | tee logs/cuda_512.txt
  ./bin/stencil_cuda_naive 512 100 3 $RAW | tee logs/cuda_naive_512.txt
fi

echo "DONE"
