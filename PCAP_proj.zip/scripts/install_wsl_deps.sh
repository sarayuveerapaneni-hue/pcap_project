#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export DEBIAN_FRONTEND=noninteractive
sudo apt-get update
sudo apt-get install -y --no-install-recommends \
  g++ make \
  openmpi-bin libopenmpi-dev \
  texlive-latex-base texlive-latex-recommended texlive-latex-extra \
  texlive-fonts-recommended texlive-publishers texlive-science \
  texlive-bibtex-extra latexmk
echo "deps installed"
mpicxx --showme:version | head -3
pdflatex --version | head -1
