#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/lib/wsl/lib"
echo "=== compilers ==="
g++ --version | head -1
echo "nvcc: $(command -v nvcc || echo missing)"
echo "mpicxx: $(command -v mpicxx || echo missing)"
echo "mpirun: $(command -v mpirun || echo missing)"
echo "pdflatex: $(command -v pdflatex || echo missing)"
echo "git: $(command -v git || echo missing)"
ls /usr/local/cuda*/bin/nvcc 2>/dev/null || true
echo "=== apt ==="
apt-cache policy nvidia-cuda-toolkit openmpi-bin libopenmpi-dev texlive-latex-extra texlive-publishers 2>/dev/null | sed -n '1,120p'
echo "=== nvidia ==="
nvidia-smi -L || true
