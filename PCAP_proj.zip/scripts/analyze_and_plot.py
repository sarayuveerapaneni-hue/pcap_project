#!/usr/bin/env python3
"""Aggregate measured runs, compare dumps to sequential, write tables and figures."""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
DUMPS = ROOT / "dumps"
FIGURES.mkdir(exist_ok=True)
RESULTS.mkdir(exist_ok=True)

SEQ_TOL = 1e-9
DISC_TOL = 1e-9

# Published peak DRAM/device bandwidth used only as roofline *bounds*,
# not as STREAM measurements.
CPU_BW_GBPS_SPEC = 76.8  # dual-channel DDR4-4800 theoretical (i7-12650H typical)
GPU_BW_GBPS_SPEC = 96.0  # RTX 3050 Laptop 4GB, 64-bit GDDR6 12 Gbps
AI = 8.0 / 48.0  # FLOP/byte, 8 FLOP / 48 B compulsory traffic


def load_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def fnum(row: dict, key: str) -> float:
    return float(row[key])


def compare_dumps() -> list[dict]:
    seq_path = DUMPS / "sequential_N64.csv"
    rows = []
    if not seq_path.exists():
        return rows
    seq = np.loadtxt(seq_path, delimiter=",")
    for p in sorted(DUMPS.glob("*_N64.csv")):
        if p.name.startswith("sequential"):
            continue
        other = np.loadtxt(p, delimiter=",")
        if other.shape != seq.shape:
            mad = math.nan
            status = "shape_mismatch"
        else:
            mad = float(np.max(np.abs(other - seq)))
            status = "pass" if mad < SEQ_TOL else "FAIL"
        rows.append({"file": p.name, "max_abs_vs_sequential": mad, "status": status})
    return rows


def median_groups(raw: list[dict]) -> list[dict]:
    groups: dict[tuple, list[dict]] = {}
    for r in raw:
        key = (r["implementation"], r["N"], r["steps"], r["workers"])
        groups.setdefault(key, []).append(r)
    out = []
    for (impl, N, steps, workers), items in groups.items():
        times = sorted(fnum(x, "runtime_seconds") for x in items)
        mid = times[len(times) // 2]
        gflops = sorted(fnum(x, "gflops") for x in items)
        disc = [fnum(x, "max_abs_discrete") for x in items]
        relc = [fnum(x, "rel_l2_continuous") for x in items]
        out.append({
            "implementation": impl,
            "N": int(N),
            "steps": int(steps),
            "workers": int(float(workers)),
            "n_repeats": len(items),
            "median_runtime_seconds": mid,
            "median_gflops": gflops[len(gflops) // 2],
            "max_abs_discrete": max(disc),
            "median_rel_l2_continuous": sorted(relc)[len(relc) // 2],
            "discrete_pass": max(disc) < DISC_TOL,
        })
    return out


def add_speedup(summary: list[dict]) -> list[dict]:
    seq = {}
    for r in summary:
        if r["implementation"] == "sequential":
            seq[(r["N"], r["steps"])] = r["median_runtime_seconds"]
    for r in summary:
        base = seq.get((r["N"], r["steps"]))
        if base and r["median_runtime_seconds"] > 0:
            r["speedup_vs_sequential"] = base / r["median_runtime_seconds"]
            r["efficiency"] = r["speedup_vs_sequential"] / max(r["workers"], 1)
        else:
            r["speedup_vs_sequential"] = math.nan
            r["efficiency"] = math.nan
        r["roofline_cpu_gflops"] = AI * CPU_BW_GBPS_SPEC
        r["roofline_gpu_gflops"] = AI * GPU_BW_GBPS_SPEC
        if r["implementation"].startswith("cuda") or "cuda" in r["implementation"]:
            r["roofline_bound"] = "gpu_dram_spec"
            ceil = r["roofline_gpu_gflops"]
        else:
            r["roofline_bound"] = "cpu_dram_spec"
            ceil = r["roofline_cpu_gflops"]
        r["pct_of_roofline"] = 100.0 * r["median_gflops"] / ceil if ceil else math.nan
    return summary


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def plot_speedup(summary: list[dict]) -> None:
    want = [
        ("sequential", 1, "Sequential"),
        ("openmp", 8, "OpenMP 8 threads"),
        ("mpi", 4, "MPI 4 ranks"),
        ("hybrid_mpi_openmp", 4, "MPI+OpenMP 2x2"),
        ("cuda_naive", None, "CUDA naive"),
        ("cuda_tiled", None, "CUDA tiled"),
        ("hybrid_mpi_cuda_openmp", None, "MPI+OpenMP+CUDA"),
    ]
    rows = [r for r in summary if r["N"] == 256 and r["steps"] == 200]
    labels, vals, colors = [], [], []
    palette = ["#4c72b0", "#dd8452", "#55a868", "#c44e52", "#8172b3", "#937860", "#da8bc3"]
    for i, (impl, workers, lab) in enumerate(want):
        cand = [r for r in rows if r["implementation"] == impl]
        if workers is not None:
            cand = [r for r in cand if r["workers"] == workers]
        if not cand:
            continue
        r = cand[0]
        if math.isnan(r["speedup_vs_sequential"]):
            continue
        labels.append(lab)
        vals.append(r["speedup_vs_sequential"])
        colors.append(palette[i % len(palette)])
    if not vals:
        return
    fig, ax = plt.subplots(figsize=(8.2, 4.2))
    ax.bar(labels, vals, color=colors)
    ax.set_ylabel("Speedup vs sequential (same N, steps)")
    ax.set_title("Measured speedup, N=256, 200 steps, median of repeats")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(FIGURES / "fig_speedup.png", dpi=200)
    plt.close(fig)


def plot_openmp_scaling(summary: list[dict]) -> None:
    rows = [r for r in summary if r["implementation"] == "openmp" and r["N"] == 256]
    if not rows:
        return
    rows = sorted(rows, key=lambda r: r["workers"])
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    w = [r["workers"] for r in rows]
    s = [r["speedup_vs_sequential"] for r in rows]
    ax.plot(w, s, "o-", label="Measured OpenMP")
    ax.plot(w, w, "--", color="gray", label="Ideal")
    ax.set_xlabel("OpenMP threads")
    ax.set_ylabel("Speedup vs sequential")
    ax.set_title("OpenMP strong scaling on one node (N=256, 200 steps)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIGURES / "fig_openmp_scaling.png", dpi=200)
    plt.close(fig)


def plot_mpi_scaling(summary: list[dict]) -> None:
    rows = [r for r in summary if r["implementation"] == "mpi" and r["N"] == 256]
    if not rows:
        return
    rows = sorted(rows, key=lambda r: r["workers"])
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    w = [r["workers"] for r in rows]
    s = [r["speedup_vs_sequential"] for r in rows]
    ax.plot(w, s, "o-", label="MPI non-blocking")
    ax.plot(w, w, "--", color="gray", label="Ideal")
    block = [r for r in summary if r["implementation"] == "mpi_blocking" and r["N"] == 256]
    if block:
        block = sorted(block, key=lambda r: r["workers"])
        ax.plot([r["workers"] for r in block], [r["speedup_vs_sequential"] for r in block],
                "s--", label="MPI blocking")
    ax.set_xlabel("MPI ranks (single node)")
    ax.set_ylabel("Speedup vs sequential")
    ax.set_title("MPI strong scaling, single node (N=256, 200 steps)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIGURES / "fig_mpi_scaling.png", dpi=200)
    plt.close(fig)


def plot_fields() -> None:
    seq_path = DUMPS / "sequential_N64.csv"
    if not seq_path.exists():
        return
    u = np.loadtxt(seq_path, delimiter=",")
    N = u.shape[0]
    h = 1.0 / (N - 1)
    t = 50 * (0.20 * h * h / 1.0)
    i = np.arange(N)
    j = np.arange(N)
    X, Y = np.meshgrid(j * h, i * h)
    uref = np.sin(np.pi * X) * np.sin(np.pi * Y) * np.exp(-2 * np.pi**2 * t)
    err = np.abs(u - uref)
    fig, axs = plt.subplots(1, 3, figsize=(10.5, 3.4))
    im0 = axs[0].imshow(u, origin="lower", cmap="inferno")
    axs[0].set_title(f"Numerical, N={N}, 50 steps")
    im1 = axs[1].imshow(uref, origin="lower", cmap="inferno")
    axs[1].set_title("Continuous analytical")
    im2 = axs[2].imshow(err, origin="lower", cmap="magma")
    axs[2].set_title("Abs. error vs continuous")
    for ax, im in zip(axs, (im0, im1, im2)):
        fig.colorbar(im, ax=ax, fraction=0.046)
        ax.set_xlabel("j")
        ax.set_ylabel("i")
    fig.tight_layout()
    fig.savefig(FIGURES / "fig_solution_validation.png", dpi=200)
    plt.close(fig)


def plot_roofline(summary: list[dict]) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ai = np.logspace(-2, 1, 200)
    cpu_peak = 200.0  # not measured; illustrative compute roof omitted for honesty
    ax.loglog(ai, AI * CPU_BW_GBPS_SPEC * np.ones_like(ai) * 0 + ai * CPU_BW_GBPS_SPEC,
              label=f"CPU DRAM spec {CPU_BW_GBPS_SPEC:.1f} GB/s")
    ax.loglog(ai, ai * GPU_BW_GBPS_SPEC, label=f"GPU DRAM spec {GPU_BW_GBPS_SPEC:.1f} GB/s")
    ax.axvline(AI, color="gray", ls=":", label="Stencil AI = 8/48 FLOP/byte")
    for r in summary:
        if r["N"] != 256:
            continue
        marker = "o" if "cuda" in r["implementation"] else "s"
        ax.loglog([AI], [r["median_gflops"]], marker, label=r["implementation"])
    ax.set_xlabel("Arithmetic intensity (FLOP/byte)")
    ax.set_ylabel("GFLOP/s (8 FLOP / interior update)")
    ax.set_title("Roofline using published DRAM specs (not STREAM)")
    ax.legend(fontsize=7, loc="upper left")
    fig.tight_layout()
    fig.savefig(FIGURES / "fig_roofline.png", dpi=200)
    plt.close(fig)
    del cpu_peak


def main() -> None:
    raw = load_csv(RESULTS / "raw_runs.csv")
    extra = load_csv(RESULTS / "strong_raw.csv") + load_csv(RESULTS / "weak_raw.csv")
    # keep extra separate
    dump_cmp = compare_dumps()
    write_csv(RESULTS / "dump_vs_sequential.csv", dump_cmp)

    summary = add_speedup(median_groups(raw))
    write_csv(RESULTS / "benchmark_summary_measured.csv", summary)

    strong = add_speedup(median_groups(load_csv(RESULTS / "strong_raw.csv")))
    write_csv(RESULTS / "strong_scaling_measured.csv", strong)
    weak = median_groups(load_csv(RESULTS / "weak_raw.csv"))
    write_csv(RESULTS / "weak_scaling_measured.csv", weak)

    plot_speedup(summary)
    plot_openmp_scaling(summary)
    plot_mpi_scaling(summary)
    plot_fields()
    plot_roofline(summary)

    meta = {
        "sequential_match_tolerance": SEQ_TOL,
        "discrete_mode_tolerance": DISC_TOL,
        "flop_convention": "8 FLOP per interior point per step",
        "byte_traffic_compulsory": "48 bytes (5 loads + 1 store of double)",
        "arithmetic_intensity": AI,
        "cpu_bw_gbps_spec": CPU_BW_GBPS_SPEC,
        "gpu_bw_gbps_spec": GPU_BW_GBPS_SPEC,
        "dump_comparisons": dump_cmp,
        "n_raw_rows": len(raw),
        "n_extra_rows": len(extra),
    }
    (RESULTS / "analysis_meta.json").write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
