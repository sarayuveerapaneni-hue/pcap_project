#!/usr/bin/env python3
"""
plot_7_implementations.py
Generates a comprehensive 3-panel comparison figure for all 7 parallel stencil implementations:
1. Sequential Baseline
2. OpenMP (Shared Memory)
3. MPI (Distributed 1D Strip Decomposition)
4. Hybrid MPI + OpenMP
5. CUDA Naive (Global Memory Access)
6. CUDA Tiled (Shared-Memory 2D Tiling)
7. Hybrid MPI + CUDA + OpenMP (3-Tier Dual Stream Overlap)

Outputs: comparison_7_implementations.png
"""
import matplotlib.pyplot as plt
import numpy as np

# Set high-quality styling
plt.rcParams.update({
    'figure.dpi': 200,
    'font.family': 'sans-serif',
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'grid.alpha': 0.3,
})

# ─────────────────────────────────────────────────────────────────────────────
# Benchmark Data: 7 Implementations at N=1024, T=200 (from IEEE Rigorous Report Table III & IV)
# ─────────────────────────────────────────────────────────────────────────────
labels = [
    "Sequential\n(1 core)",
    "OpenMP\n(8 threads)",
    "MPI\n(4 ranks)",
    "MPI\n(8 ranks)",
    "Hybrid\n(2R × 2T)",
    "Hybrid 3-Tier\n(MPI+CUDA+OMP)",
    "CUDA Naive\n(GPU)",
    "CUDA Tiled\n(GPU shared)"
]

times_s = [
    0.219708,  # Sequential
    0.082536,  # OpenMP 8T
    0.088254,  # MPI 4R
    0.047654,  # MPI 8R
    0.106827,  # Hybrid MPI+OMP (2R x 2T)
    0.070979,  # Hybrid 3-tier (2R x 2T + GPU)
    0.030119,  # CUDA Naive (inclusive)
    0.030083   # CUDA Tiled (inclusive)
]

seq_time = times_s[0]
speedups = [seq_time / t for t in times_s]

# Calculate GFLOP/s under 8(N-2)^2 * T / (t * 1e9) convention for N=1024, T=200
N = 1024
T = 200
flops = 8 * (N - 2)**2 * T
gflops = [(flops / (t * 1e9)) for t in times_s]

# Distinct palette per paradigm
colors = [
    "#4A5568",  # Sequential (slate gray)
    "#3182CE",  # OpenMP (blue)
    "#DD6B20",  # MPI 4R (orange)
    "#C05621",  # MPI 8R (dark orange)
    "#805AD5",  # Hybrid MPI+OMP (purple)
    "#D53F8C",  # Hybrid 3-Tier (magenta/pink)
    "#38A169",  # CUDA Naive (green)
    "#276749"   # CUDA Tiled (forest green)
]

fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(16, 5.2))
fig.suptitle("Performance Comparison Across All 7 Stencil Implementations (N = 1024 × 1024, T = 200)", 
             fontsize=14, fontweight='bold', y=1.02)

# Panel 1: Execution Time (seconds) - lower is better
bars1 = ax1.bar(range(len(labels)), times_s, color=colors, width=0.65, edgecolor='black', linewidth=0.5)
ax1.set_ylabel("Execution Time (seconds) [Lower is Better]", fontweight='bold')
ax1.set_title("Median Wall-Clock Time", fontweight='bold', pad=10)
ax1.set_xticks(range(len(labels)))
ax1.set_xticklabels(labels, rotation=35, ha='right', fontsize=9)
ax1.grid(axis='y', linestyle='--')
for bar in bars1:
    h = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., h + 0.004, f"{h:.3f}s", ha='center', va='bottom', fontsize=8.5, fontweight='bold')

# Panel 2: Speedup vs Sequential - higher is better
bars2 = ax2.bar(range(len(labels)), speedups, color=colors, width=0.65, edgecolor='black', linewidth=0.5)
ax2.axhline(1.0, color='gray', linestyle='--', linewidth=1.2, label='Baseline (1.0×)')
ax2.set_ylabel("Speedup vs Sequential (×) [Higher is Better]", fontweight='bold')
ax2.set_title("Speedup vs CPU Baseline", fontweight='bold', pad=10)
ax2.set_xticks(range(len(labels)))
ax2.set_xticklabels(labels, rotation=35, ha='right', fontsize=9)
ax2.grid(axis='y', linestyle='--')
ax2.legend(loc='upper left', frameon=True)
for bar in bars2:
    h = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., h + 0.15, f"{h:.2f}×", ha='center', va='bottom', fontsize=8.5, fontweight='bold')

# Panel 3: Computational Throughput (GFLOP/s) - higher is better
bars3 = ax3.bar(range(len(labels)), gflops, color=colors, width=0.65, edgecolor='black', linewidth=0.5)
ax3.set_ylabel("Computational Throughput (GFLOP/s)", fontweight='bold')
ax3.set_title("Achieved GFLOP/s", fontweight='bold', pad=10)
ax3.set_xticks(range(len(labels)))
ax3.set_xticklabels(labels, rotation=35, ha='right', fontsize=9)
ax3.grid(axis='y', linestyle='--')
for bar in bars3:
    h = bar.get_height()
    ax3.text(bar.get_x() + bar.get_width()/2., h + 0.9, f"{h:.1f}", ha='center', va='bottom', fontsize=8.5, fontweight='bold')

plt.tight_layout()
plt.savefig("comparison_7_implementations.png", dpi=200, bbox_inches='tight')
plt.close()
print("Successfully generated comparison_7_implementations.png")
