#!/usr/bin/env python3
"""
stencil_runner.py
-----------------
Performance-aware backend selector for the 2D heat-diffusion stencil solver.

This script mirrors the role of smart_building_runner.py from the sample
project but targets the stencil implementations described in the PS2 report:

  sequential   -> stencil_sequential
  openmp       -> stencil_openmp
  mpi          -> stencil_mpi          (mpirun)
  hybrid       -> stencil_hybrid       (mpirun + OMP_NUM_THREADS)
  cuda_naive   -> stencil_cuda_naive
  cuda_tiled   -> stencil_cuda        (default CUDA with shared-mem tiling)

Workflow
--------
1. Read benchmark_summary.csv (produced by the Colab benchmark notebook).
2. Choose the fastest verified implementation that is actually available
   on the current machine.
3. Run it with the given problem size and time steps.
4. Write backend_decision.json with all configuration details.
"""

import argparse
import json
import os
import shutil
import subprocess
from pathlib import Path

import pandas as pd


# ---------------------------------------------------------------------------
# Availability checks
# ---------------------------------------------------------------------------

def cuda_available() -> bool:
    """Return True if at least one CUDA-capable GPU is visible."""
    if shutil.which("nvidia-smi") is None:
        return False
    result = subprocess.run(
        ["nvidia-smi", "-L"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


def mpi_available() -> bool:
    return shutil.which("mpirun") is not None


def binary_path(name: str) -> str:
    """Return the expected absolute path for a compiled binary."""
    # Colab / Linux convention: binaries compiled to /content/
    return f"/content/{name}"


IMPLEMENTATION_BINARIES = {
    "sequential":  ["stencil_sequential"],
    "openmp":      ["stencil_openmp"],
    "mpi":         ["stencil_mpi"],
    "hybrid":      ["stencil_hybrid"],
    "cuda_naive":  ["stencil_cuda_naive"],
    "cuda_tiled":  ["stencil_cuda"],
}


def implementation_available(method: str) -> bool:
    binaries = IMPLEMENTATION_BINARIES.get(method, [])
    for b in binaries:
        if not Path(binary_path(b)).exists():
            return False
    if method in {"mpi", "hybrid"}:
        return mpi_available()
    if method in {"cuda_naive", "cuda_tiled"}:
        return cuda_available()
    return True


# ---------------------------------------------------------------------------
# Backend selection
# ---------------------------------------------------------------------------

def select_fastest_backend(summary_path: str) -> dict:
    """Parse benchmark_summary.csv and return the fastest available impl."""
    summary = pd.read_csv(summary_path)

    # Keep only rows that passed correctness validation
    if "correct_result" in summary.columns:
        summary = summary[
            summary["correct_result"]
            .astype(str)
            .str.lower()
            .eq("true")
        ].copy()

    summary = summary.sort_values("median_time_seconds")

    for _, row in summary.iterrows():
        method = str(row["implementation"]).lower()
        if implementation_available(method):
            return {
                "method":          method,
                "measured_time":   float(row["median_time_seconds"]),
                "measured_speedup": float(row["speedup"]),
            }

    raise RuntimeError("No compiled implementation is available.")


# ---------------------------------------------------------------------------
# Hybrid configuration (reads hybrid_tuning.csv if available)
# ---------------------------------------------------------------------------

def get_hybrid_configuration() -> tuple[int, int]:
    tuning = Path("/content/hybrid_tuning.csv")
    if not tuning.exists():
        return 2, 2   # safe default: 2 MPI ranks, 2 OMP threads

    df = pd.read_csv(tuning)
    best = df.sort_values("median_time").iloc[0]
    return int(best["mpi_ranks"]), int(best["threads_per_rank"])


# ---------------------------------------------------------------------------
# Command builder
# ---------------------------------------------------------------------------

def build_command(
    method: str,
    N: int,
    steps: int,
    benchmark_csv: str,
) -> tuple[list[str], dict[str, str]]:
    """Return (command_list, env_dict) ready for subprocess.run."""
    args = [str(N), str(steps), benchmark_csv]
    env  = os.environ.copy()
    env["OMPI_ALLOW_RUN_AS_ROOT"]         = "1"
    env["OMPI_ALLOW_RUN_AS_ROOT_CONFIRM"] = "1"
    env["OMP_DYNAMIC"]                    = "FALSE"

    if method == "sequential":
        cmd = [binary_path("stencil_sequential"), *args]

    elif method == "openmp":
        env["OMP_NUM_THREADS"] = str(min(4, os.cpu_count() or 1))
        cmd = [binary_path("stencil_openmp"), *args]

    elif method == "mpi":
        ranks = min(4, os.cpu_count() or 1)
        cmd = [
            "mpirun", "--allow-run-as-root", "--oversubscribe",
            "--bind-to", "none",
            "-np", str(ranks),
            binary_path("stencil_mpi"), *args,
        ]

    elif method == "hybrid":
        ranks, threads = get_hybrid_configuration()
        env["OMP_NUM_THREADS"] = str(threads)
        cmd = [
            "mpirun", "--allow-run-as-root", "--oversubscribe",
            "--bind-to", "none",
            "-np", str(ranks),
            binary_path("stencil_hybrid"), *args,
        ]

    elif method == "cuda_naive":
        cmd = [binary_path("stencil_cuda_naive"), *args]

    elif method == "cuda_tiled":
        cmd = [binary_path("stencil_cuda"), *args]

    else:
        raise ValueError(f"Unknown implementation: {method!r}")

    return cmd, env


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Performance-aware stencil runner"
    )
    parser.add_argument("--N",     type=int, default=1024,
                        help="Grid dimension (N x N)")
    parser.add_argument("--steps", type=int, default=200,
                        help="Number of time steps")
    parser.add_argument(
        "--benchmark_csv",
        default="/content/benchmark_runs.csv",
        help="Path to the benchmark summary CSV",
    )
    parser.add_argument(
        "--summary_csv",
        default="/content/benchmark_summary.csv",
        help="Path to the per-run summary CSV produced during benchmarking",
    )
    args = parser.parse_args()

    # --- Select fastest verified backend ---
    selection = select_fastest_backend(args.summary_csv)
    method = selection["method"]

    cmd, env = build_command(
        method, args.N, args.steps, args.benchmark_csv
    )

    print("=" * 60)
    print("PERFORMANCE-AWARE BACKEND SELECTION")
    print("=" * 60)
    print(f"  Selected implementation : {method}")
    print(f"  Measured median runtime : {selection['measured_time']:.6f} s")
    print(f"  Measured speedup        : {selection['measured_speedup']:.3f}x")
    print(f"  CPU logical cores       : {os.cpu_count()}")
    print(f"  CUDA available          : {cuda_available()}")
    print(f"  Problem size N          : {args.N}")
    print(f"  Time steps              : {args.steps}")
    print("=" * 60)
    print("\nRunning stencil computation...\n")

    result = subprocess.run(cmd, env=env, capture_output=True, text=True)
    print(result.stdout)

    if result.returncode != 0:
        print(result.stderr)
        raise RuntimeError(f"{method} execution failed.")

    # --- Persist stdout ---
    Path("/content/selected_backend_output.txt").write_text(
        result.stdout, encoding="utf-8"
    )

    # --- Persist decision metadata ---
    decision = {
        "selected_implementation":      method,
        "measured_median_runtime_s":    selection["measured_time"],
        "measured_speedup":             selection["measured_speedup"],
        "N":                            args.N,
        "steps":                        args.steps,
        "cpu_logical_cores":            os.cpu_count(),
        "cuda_available":               cuda_available(),
        "command":                      cmd,
    }
    Path("/content/backend_decision.json").write_text(
        json.dumps(decision, indent=2), encoding="utf-8"
    )
    print("\nDecision saved to /content/backend_decision.json")


if __name__ == "__main__":
    main()
