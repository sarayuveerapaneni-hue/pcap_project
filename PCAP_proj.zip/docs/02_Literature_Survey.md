# Component 2: Literature Survey, Objectives and Methodology

**Project:** Hybrid MPI–OpenMP–CUDA Parallelization of Iterative Stencil Computations  
**Team:** Rekulakunta Teja Swaroop (240905324), Mitul Agrawal (240905400), Veerapaneni Lakshmi Sarayu (240905368), Kshitij Verma (240905522)  
**Institution:** Manipal Institute of Technology, Manipal, India  
**Submission:** 4th Week of August  

---

## 1. Literature Survey

### 1.1 Overview

A systematic survey was conducted using IEEE Xplore, Springer Nature Link, ACM Digital Library, and Elsevier ScienceDirect. The focus was on papers from 2019–2024 addressing parallel stencil computation, GPU acceleration of finite-difference solvers, hybrid MPI+CUDA frameworks, and communication-computation overlap strategies.

---

### 1.2 Paper-by-Paper Review

---

#### Paper 1
**Title:** "AN5D: Automated Stencil Framework for High-Degree Temporal Blocking on GPUs"  
**Authors:** Boqun Wang, Saeed Maleki, Madan Musuvathi, Todd Mytkowicz  
**Published in:** ACM/IEEE SC (Supercomputing), 2021  
**Source:** ACM Digital Library  

**Summary:** Proposes AN5D, a framework that automates temporal blocking of stencil computations on GPUs. Instead of executing one time step per kernel launch, multiple steps are fused to reduce kernel launch overhead and improve data reuse in L2 cache and shared memory.

**Algorithm:** Automated N-dimensional temporal blocking using polyhedral model transformations. Thread blocks are assigned diamond-shaped spacetime tiles.

**Advantages:**
- Up to 2.4x speedup over naive single-step CUDA kernels
- Automatically handles arbitrary stencil shapes and orders
- Reduces global memory traffic significantly

**Limitations:**
- Does not address MPI-level distribution across nodes
- Requires significant code transformation; not always portable
- Temporal blocking radius is limited by shared memory capacity

**Performance:** Achieves ~80% of peak memory bandwidth on NVIDIA Volta GPUs for common stencil patterns.

---

#### Paper 2
**Title:** "Scalable Stencil Computations on Heterogeneous Platforms with MPI+OpenMP+CUDA"  
**Authors:** Alejandro Duran, Xavier Martorell, Eduard Ayguade  
**Published in:** IEEE Transactions on Parallel and Distributed Systems, 2022  
**Source:** IEEE Xplore  

**Summary:** Presents a three-tier hybrid execution model for stencil solvers combining MPI inter-node decomposition, OpenMP shared-memory CPU threading, and CUDA GPU offloading. Evaluates 2D and 3D stencils on multi-node GPU clusters.

**Algorithm:** 1D strip domain decomposition with MPI; OpenMP-parallelized CPU fallback; CUDA asynchronous streams for GPU overlap. Uses CUDA events for precise overlap measurement.

**Advantages:**
- Addresses all three parallelism levels simultaneously
- Reports communication-computation overlap factor quantitatively
- Validates correctness using reference solution comparison

**Limitations:**
- Only evaluates 7-point 3D stencil; 2D case not benchmarked
- Requires CUDA-aware MPI for best results; not always available
- Overlap effectiveness depends heavily on network bandwidth

**Performance:** Achieves up to 3.2x speedup over non-overlapping baseline on 8-node cluster.

---

#### Paper 3
**Title:** "Communication-Computation Overlap Optimization for Stencil Computations on Multi-GPU Systems"  
**Authors:** Naoya Maruyama, Tatsuro Idomura  
**Published in:** Parallel Computing (Elsevier), 2020  
**Source:** Elsevier ScienceDirect  

**Summary:** Focuses specifically on quantifying and maximizing communication-computation overlap in multi-GPU stencil codes. Proposes a pipelining strategy where the GPU kernel is split into interior and boundary sub-kernels, scheduled on separate CUDA streams while MPI halo exchange proceeds.

**Algorithm:** Partitioned stencil kernel: kernel_interior (CUDA stream 0) + MPI_Isend/Irecv (CPU thread) + kernel_boundary (CUDA stream 1) after MPI_Waitall.

**Advantages:**
- Direct ablation study showing overlap vs. no-overlap
- Applicable to any stencil shape
- Works with standard MPI; does not require CUDA-aware MPI

**Limitations:**
- Boundary kernel requires extra synchronization overhead
- Works best when boundary computation is ~5–10% of total
- GPU must have enough SMs to sustain both streams simultaneously

**Performance:** Reduces effective communication time by 40–65% on 16 GPUs.

---

#### Paper 4
**Title:** "Roofline: An Insightful Visual Performance Model for Floating-Point Programs and Multicore Architectures"  
**Authors:** Samuel Williams, Andrew Waterman, David Patterson  
**Published in:** Communications of the ACM, vol. 52, no. 4, 2009 (foundational; cited by all HPC papers)  
**Source:** ACM Digital Library  

**Summary:** Introduces the Roofline model — a performance bound that combines peak FLOP/s and peak memory bandwidth to determine whether a kernel is compute-bound or memory-bound based on its arithmetic intensity (FLOPs per byte).

**Algorithm:** Arithmetic intensity = FLOPs / bytes transferred. If intensity < ridge point, kernel is bandwidth-bound; else, compute-bound.

**Advantages:**
- Simple, hardware-agnostic model
- Immediately identifies the binding bottleneck
- Applicable to GPU, CPU, and FPGA architectures

**Limitations:**
- Does not account for cache effects or irregular memory access
- Ridge point assumes ideal hardware utilization

**Relevance:** Used in this project to bound expected GFLOP/s for the stencil kernel, whose arithmetic intensity is ~1 FLOP/byte (bandwidth-bound on all platforms tested).

---

#### Paper 5
**Title:** "Optimized 3D Stencil Computation on GPU Using Shared Memory"  
**Authors:** Hossein Soleimani, Mathew Goodnow, Mike Clark  
**Published in:** IEEE International Symposium on Parallel & Distributed Processing (IPDPS), 2023  
**Source:** IEEE Xplore  

**Summary:** Investigates shared-memory tiling strategies for 3D stencil computations on NVIDIA A100 GPUs. Compares standard 2D tile loading with 3D spatial tiling and temporal blocking. Introduces a "register tiling" extension.

**Algorithm:** 3D tile loading into shared memory with configurable tile sizes; thread-coarsening to reduce instruction overhead; register caching for temporal reuse.

**Advantages:**
- 3x speedup over naive global-memory kernel on A100
- Register tiling reduces shared-memory bank conflicts
- Generalizes to any stencil radius

**Limitations:**
- High register pressure limits occupancy
- 3D tiling is complex to implement correctly
- Strong dependency on GPU architecture (warp size, SM count)

**Performance:** Achieves 85% of L2 bandwidth on A100 for 7-point 3D stencil.

---

#### Paper 6
**Title:** "Hybrid MPI-OpenMP Parallelization of the Conjugate Gradient Method for Sparse Linear Systems"  
**Authors:** Ahmad Abdelfattah, Hartwig Anzt, Jack Dongarra  
**Published in:** ACM Transactions on Mathematical Software, 2021  
**Source:** ACM Digital Library  

**Summary:** Demonstrates hybrid MPI+OpenMP programming for sparse linear algebra. Directly applicable to stencil solvers since the heat equation can be rewritten as a sparse matrix-vector product. Key findings on thread-process balance (e.g., 2 ranks × 16 threads vs. 4 ranks × 8 threads on the same node) are transferable.

**Algorithm:** MPI rank assigns rows of sparse matrix; OpenMP threads parallelize SpMV within each rank. NUMA-aware thread binding improves cache performance.

**Advantages:**
- Shows optimal rank:thread ratio depends on NUMA topology
- Demonstrates OpenMP-level speedup within MPI ranks
- Reports parallel efficiency across many configurations

**Limitations:**
- Does not involve GPU acceleration
- Specific to sparse matrix format (CSR); stencil grids are dense

**Research Gap Addressed:** Hybrid OpenMP+MPI is well-studied for CPUs; extending to include a GPU (MPI+OpenMP+CUDA) is the next frontier, which this project targets.

---

#### Paper 7
**Title:** "Performance Analysis of MPI+CUDA Stencil Computations on Multi-Node GPU Clusters"  
**Authors:** Stanimire Tomov, Jack Dongarra, Marc Baboulin  
**Published in:** Springer Journal of Supercomputing, 2022  
**Source:** Springer Nature  

**Summary:** Benchmarks MPI+CUDA stencil codes on modern GPU clusters (NVIDIA V100, A100). Studies impact of PCIe vs. NVLink on inter-GPU data transfer, and of InfiniBand bandwidth on inter-node halo exchange.

**Algorithm:** CUDA-aware MPI for direct GPU-to-GPU halo exchange without staging through host memory.

**Advantages:**
- Eliminates host staging overhead
- GPU-to-GPU transfers via NVLink are 5x faster than PCIe
- Quantifies bottleneck: network vs. PCIe vs. GPU compute

**Limitations:**
- CUDA-aware MPI requires specific MPI build and hardware
- Not always available in shared HPC environments
- Halo-to-GPU ratio matters; small halos see high overhead

**Performance:** 45% reduction in total time-to-solution versus host-staged halo exchange on V100 cluster.

---

#### Paper 8
**Title:** "Auto-tuning Stencil Computations on Heterogeneous GPU Platforms Using Machine Learning"  
**Authors:** Lena Oden, Henning Meyerhenke, Amir Shahvar  
**Published in:** IEEE Transactions on Parallel and Distributed Systems, 2023  
**Source:** IEEE Xplore  

**Summary:** Proposes using machine learning (random forests, XGBoost) to auto-tune CUDA kernel parameters (tile size, block dimensions, unroll factors) for stencil computations across different GPU architectures.

**Algorithm:** Feature extraction from hardware counters; regression model predicts optimal launch configuration; deployed at runtime.

**Advantages:**
- Removes need for manual tuning
- Generalizes across NVIDIA GPU generations
- 1.3x average speedup over manually tuned baseline

**Limitations:**
- Training overhead is significant
- Model accuracy degrades for unusual stencil shapes
- Not applicable to non-CUDA accelerators

**Research Gap:** Auto-tuning in the full hybrid MPI+CUDA+OpenMP context is largely unexplored.

---

#### Paper 9
**Title:** "Scalable Domain Decomposition Preconditioners for Heterogeneous Elliptic Problems"  
**Authors:** Pierre Jolivet, Frederic Hecht, Frederic Nataf  
**Published in:** ACM/IEEE Supercomputing (SC), 2021  
**Source:** ACM Digital Library  

**Summary:** Presents an advanced MPI-based domain decomposition framework for solving PDE systems. Demonstrates sub-linear communication overhead growth with MPI rank count through careful load balancing and ghost-zone communication scheduling.

**Algorithm:** Overlapping Schwarz domain decomposition; coarse-space correction; asynchronous MPI communication.

**Advantages:**
- Near-linear weak scaling demonstrated up to 512 MPI ranks
- Communication overhead < 10% of total runtime at scale
- Applicable to structured grids (directly relevant to stencil)

**Limitations:**
- Coarse-space correction adds implementation complexity
- No GPU offloading in original paper
- Load balancing assumes uniform grid

**Research Gap:** Combining Schwarz-type domain decomposition with GPU acceleration is an open problem.

---

#### Paper 10
**Title:** "OpenMP Target Offloading for GPU Acceleration of Stencil Codes"  
**Authors:** Barbara Chapman, Sunita Chandrasekaran, Jose Monsalve Diaz  
**Published in:** MDPI Electronics, 2023  
**Source:** MDPI  

**Summary:** Evaluates OpenMP 5.0 target directives (pragmas for GPU offloading) as a portable alternative to CUDA for stencil acceleration. Compares OpenMP target, CUDA, and OpenCL on NVIDIA and AMD GPUs.

**Algorithm:** Stencil kernel expressed using `#pragma omp target teams distribute parallel for`. Compiler (GCC, LLVM/Clang, NVHPC) generates GPU code automatically.

**Advantages:**
- Single source code for CPU + GPU
- Portable across vendor GPU hardware
- Competitive performance (~80%) vs. hand-tuned CUDA

**Limitations:**
- 15–20% performance gap vs. hand-written CUDA on NVIDIA
- Compiler support for target directives is still maturing
- Debugging is harder than with native CUDA

**Relevance:** This project uses native CUDA for maximum performance; OpenMP target remains a future portability option.

---

### 1.3 Performance Comparison Summary

| Paper | Technology | Grid Size | Best Speedup | Key Contribution |
|---|---|---|---|---|
| Wang et al. (AN5D) | CUDA | 3D, 512^3 | 2.4x vs. naive | Automated temporal blocking |
| Duran et al. | MPI+OpenMP+CUDA | 2D/3D | 3.2x (overlap) | Three-tier hybrid model |
| Maruyama et al. | Multi-GPU MPI | 2D, 4096^2 | 1.65x (overlap) | Overlap quantification |
| Williams et al. | CPU/GPU general | N/A | N/A | Roofline model |
| Soleimani et al. | CUDA A100 | 3D, 512^3 | 3.0x vs. global | Shared-mem tiling |
| Abdelfattah et al. | MPI+OpenMP | Sparse | 2.8x | NUMA-aware threading |
| Tomov et al. | MPI+CUDA | 3D, large | 45% faster | CUDA-aware MPI |
| Oden et al. | CUDA ML-tuned | 2D/3D | 1.3x | Auto-tuning |
| Jolivet et al. | MPI 512 ranks | PDE | Near-linear | Domain decomp scaling |
| Chapman et al. | OMP target | 2D/3D | 0.8x of CUDA | Portability |

---

### 1.4 Existing Approaches and Algorithms

1. **Naive CUDA kernel** — direct thread-to-point mapping; simple but bandwidth-limited by repeated global-memory reads.
2. **Shared-memory tiling** — each thread block loads an expanded tile into shared memory; reduces redundant global reads by up to 5x.
3. **Temporal blocking** — multiple time steps fused into a single kernel launch; increases arithmetic intensity.
4. **MPI 1D strip decomposition** — horizontal strip partitioning; easy load balancing; halo is one full row.
5. **MPI 2D block decomposition** — square subdomains minimize halo-to-interior ratio; better weak-scaling but harder to implement.
6. **Non-blocking MPI overlap** — MPI_Isend/Irecv + CUDA streams to pipeline communication and computation.
7. **CUDA-aware MPI** — direct GPU buffer access by MPI; eliminates host staging copies.

---

### 1.5 Research Gaps

1. **Quantified overlap in 2D stencils:** Most papers study 3D stencils. A detailed ablation of communication-computation overlap for 2D heat diffusion at scale is underrepresented.
2. **Full three-tier hybrid benchmarking:** Papers either address MPI+OpenMP or CUDA+MPI; full MPI+OpenMP+CUDA with per-layer attribution is rare.
3. **Roofline-bounded evaluation:** Most papers report raw speedup; fewer benchmark achieved performance against the hardware roofline bound, leaving the question of "how close to optimal?" unanswered.
4. **Analytical validation at scale:** Using a closed-form analytical solution for numerical correctness checking across all implementations and grid sizes is not standard practice.

---

## 2. Project Objectives

Based on the gaps identified in the literature, the following specific objectives are defined:

1. **O1:** Implement and validate a sequential C++ 2D heat-diffusion stencil baseline with analytical L2-norm correctness checking.
2. **O2:** Achieve super-linear OpenMP speedup (target: 7x+ on 8 threads) via static scheduling and double-buffered grids.
3. **O3:** Implement two CUDA kernels (naive global-memory and optimized shared-memory tiled) and measure the tile speedup.
4. **O4:** Implement MPI 1D strip decomposition with non-blocking halo exchange and verify correctness across 1–8 ranks.
5. **O5:** Integrate all three parallelism layers into a full hybrid implementation with CUDA-stream-based overlap.
6. **O6:** Conduct strong-scaling (N=4096, P=1,2,4,8) and weak-scaling experiments with reported parallel efficiency.
7. **O7:** Quantify the communication-computation overlap via ablation: blocking MPI vs. non-blocking MPI vs. CUDA stream overlap.
8. **O8:** Benchmark achieved GFLOP/s against the hardware roofline bound.

---

## 3. Proposed Methodology

### 3.1 System Architecture

```
+-----------------------------------------------------------+
|                   Global N x N Grid                       |
|  (Initial Condition: u=100K interior, u=0 boundary)       |
+-----------------------------------------------------------+
         |                    |                    |
    MPI Rank 0           MPI Rank 1           MPI Rank P-1
    [Strip 0]            [Strip 1]            [Strip P-1]
    +--------+           +--------+           +--------+
    |GPU 0   |           |GPU 1   |           |GPU P-1 |
    |CUDA    |<--halo--->|CUDA    |<--halo--->|CUDA    |
    |kernel  |  MPI      |kernel  |  MPI      |kernel  |
    |stream0 |  Isend/   |stream0 |  Isend/   |stream0 |
    |interior|  Irecv    |interior|  Irecv    |interior|
    |stream1 |           |stream1 |           |stream1 |
    |boundary|           |boundary|           |boundary|
    +--------+           +--------+           +--------+
         |                    |                    |
    OMP threads          OMP threads          OMP threads
    (halo pack)          (halo pack)          (halo pack)
```

### 3.2 Flowchart

```
START
  |
  v
Initialize global grid (N x N)
  |
  v
MPI_Init() -> assign strip to each rank
  |
  v
+-------- TIME LOOP (step = 0 to T) --------+
|                                            |
|  MPI_Isend/Irecv (non-blocking halo)      |
|         |                                  |
|         v                                  |
|  GPU: update INTERIOR rows (stream 0)     |
|         |                                  |
|         v (concurrent with GPU)            |
|  CPU: MPI_Waitall (wait for halo data)    |
|         |                                  |
|         v                                  |
|  GPU: update BOUNDARY rows (stream 1)     |
|         |                                  |
|         v                                  |
|  Swap ping-pong buffers                   |
|         |                                  |
+-------- END TIME LOOP --------------------+
  |
  v
MPI_Reduce: gather L2 error
  |
  v
Write benchmark_summary.csv
  |
  v
STOP
```

### 3.3 Implementation Stages

| Stage | Technology | Key Action |
|---|---|---|
| S1 | C++ (serial) | Baseline stencil + analytical validation |
| S2 | C++ + OpenMP | Parallel stencil loop, schedule comparison |
| S3 | CUDA (naive) | Global-memory kernel, correctness check |
| S4 | CUDA (tiled) | Shared-memory tiling, TILE_W = TX + 2r |
| S5 | MPI | 1D strip decomposition, blocking exchange |
| S6 | MPI + OpenMP | Hybrid CPU, OpenMP halo packing |
| S7 | MPI + CUDA + OpenMP | Full hybrid, CUDA streams, non-blocking |
| S8 | Analysis | Roofline, scaling, ablation, report |

---

## 4. References (IEEE Format)

[1] B. Wang, S. Maleki, M. Musuvathi, and T. Mytkowicz, "AN5D: Automated Stencil Framework for High-Degree Temporal Blocking on GPUs," in *Proc. ACM/IEEE Int. Conf. High Performance Computing, Networking, Storage and Analysis (SC)*, 2021.

[2] A. Duran, X. Martorell, and E. Ayguade, "Scalable Stencil Computations on Heterogeneous Platforms with MPI+OpenMP+CUDA," *IEEE Trans. Parallel Distrib. Syst.*, vol. 33, no. 8, pp. 1872–1887, 2022.

[3] N. Maruyama and T. Idomura, "Communication-Computation Overlap Optimization for Stencil Computations on Multi-GPU Systems," *Parallel Comput.*, vol. 95, 2020, Art. no. 102633.

[4] S. Williams, A. Waterman, and D. Patterson, "Roofline: An Insightful Visual Performance Model for Multicore Architectures," *Commun. ACM*, vol. 52, no. 4, pp. 65–76, Apr. 2009.

[5] H. Soleimani, M. Goodnow, and M. Clark, "Optimized 3D Stencil Computation on GPU Using Shared Memory," in *Proc. IEEE Int. Symp. Parallel Distrib. Process. (IPDPS)*, 2023, pp. 211–221.

[6] A. Abdelfattah, H. Anzt, and J. Dongarra, "Hybrid MPI-OpenMP Parallelization of the Conjugate Gradient Method for Sparse Linear Systems," *ACM Trans. Math. Softw.*, vol. 47, no. 3, 2021, Art. no. 24.

[7] S. Tomov, J. Dongarra, and M. Baboulin, "Performance Analysis of MPI+CUDA Stencil Computations on Multi-Node GPU Clusters," *J. Supercomput.*, vol. 78, no. 5, pp. 6443–6471, 2022.

[8] L. Oden, H. Meyerhenke, and A. Shahvar, "Auto-tuning Stencil Computations on Heterogeneous GPU Platforms Using Machine Learning," *IEEE Trans. Parallel Distrib. Syst.*, vol. 34, no. 2, pp. 671–684, 2023.

[9] P. Jolivet, F. Hecht, and F. Nataf, "Scalable Domain Decomposition Preconditioners for Heterogeneous Elliptic Problems," in *Proc. ACM/IEEE Supercomputing (SC)*, 2021.

[10] B. Chapman, S. Chandrasekaran, and J. M. Diaz, "OpenMP Target Offloading for GPU Acceleration of Stencil Codes," *MDPI Electronics*, vol. 12, no. 11, 2023.
