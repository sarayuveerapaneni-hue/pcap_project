# Component 1: Project Title and Proposal Submission

**Course:** Parallel Computing Applications (PCAP) Laboratory  
**Institution:** Manipal Institute of Technology, Manipal, India  
**Department:** Computer Science and Engineering  
**Submission:** 4th Week of August  

---

## Team Members

| Name | Registration Number | Department |
|---|---|---|
| Rekulakunta Teja Swaroop | 240905324 | CSE, MIT Manipal |
| Mitul Agrawal | 240905400 | CSE, MIT Manipal |
| Veerapaneni Lakshmi Sarayu | 240905368 | CSE, MIT Manipal |
| Kshitij Verma | 240905522 | CSE, MIT Manipal |

---

## 1. Final Project Title

**Hybrid MPI–OpenMP–CUDA Parallelization of Iterative Stencil Computations for Large-Scale Scientific Simulation: A Scalability and Communication–Computation Overlap Study**

---

## 2. Problem Statement

Iterative stencil computations — repeated nearest-neighbour updates over a structured grid — underlie many critical scientific simulations, including heat diffusion, wave propagation, fluid dynamics, and seismic modelling. For a 2D grid of size N x N updated for T time steps with a 5-point stencil, sequential execution exhibits O(N^2 * T) time complexity. For realistic problem sizes (N >= 8192, T in the thousands), this becomes computationally intractable on a single core.

Furthermore, grids large enough to be scientifically meaningful frequently exceed the memory capacity of a single node or a single GPU, making distributed execution a necessity rather than an optimization. The technical challenge is three-fold:

1. **Intra-node parallelism** — utilizing all CPU cores (OpenMP) and GPU cores (CUDA) within a single machine.
2. **Inter-node parallelism** — partitioning the grid across multiple compute nodes using MPI domain decomposition.
3. **Communication-computation overlap** — hiding MPI halo exchange latency by concurrently computing interior points on the GPU using CUDA streams and non-blocking MPI calls.

---

## 3. Motivation for Selecting the Problem

Stencil kernels are pervasive in HPC, appearing in finite-difference solvers, cellular automata, image filtering, and physics simulations. They are among the most studied memory-bandwidth-bound workloads, ideal for a structured performance study. Key motivations:

- **Practical relevance:** Direct applicability to computational fluid dynamics, climate modelling, and image processing.
- **Memory-bound nature:** Low arithmetic intensity makes stencil kernels sensitive to memory hierarchy — ideal for shared-memory tiling on GPUs.
- **Hybrid parallelism opportunity:** MPI + OpenMP + CUDA represents a realistic production HPC programming model.
- **Research gap:** Most published work studies MPI or CUDA in isolation; quantifying overlap gain in the full hybrid setting is a meaningful research contribution.

---

## 4. Project Objectives

1. Develop a single-threaded C++ reference implementation of a 2D heat-diffusion stencil solver with closed-form analytical correctness checking.
2. Implement a CPU shared-memory parallel version using OpenMP with static/dynamic/guided scheduling and double-buffered grids.
3. Implement a baseline single-GPU CUDA kernel (direct global-memory access) and an optimized shared-memory tiled kernel.
4. Implement MPI-based 1D strip domain decomposition with blocking halo exchange as a correctness baseline.
5. Extend to the full **Hybrid MPI + CUDA + OpenMP** version: one GPU per rank, non-blocking halo exchange overlapped with interior computation via CUDA streams.
6. Conduct strong-scaling and weak-scaling experiments and measure achieved GFLOP/s against a roofline estimate.
7. Quantify the communication-computation overlap optimization via ablation study.
8. Validate numerical correctness against the analytical solution within a stated L2-norm error tolerance.

---

## 5. Parallel Programming Models to be Used

| Model | Role in the Project |
|---|---|
| **OpenMP** | Shared-memory CPU parallelism; thread-parallel stencil loops; host-side halo packing/unpacking |
| **MPI (OpenMPI/MPICH)** | Inter-node distributed-memory domain decomposition; non-blocking halo exchange via MPI_Isend/MPI_Irecv |
| **CUDA C++ (v12.x)** | Intra-node GPU acceleration; shared-memory tiled stencil kernel; CUDA streams for overlap |
| **Hybrid: MPI + OpenMP + CUDA** | Full three-tier parallelism combining all the above |

---

## 6. Proposed Methodology

### Step 1 — Reference Implementation
A sequential C++ implementation (stencil_cpu.cpp) with a 5-point finite-difference heat equation solver and an analytical reference for L2 error validation.

### Step 2 — OpenMP Parallelization
Add `#pragma omp parallel for` to the stencil loop. Compare scheduling strategies (static, dynamic, guided). Report speedup and efficiency over the sequential baseline.

### Step 3 — CUDA Kernel (Naive to Tiled)
- **Naive kernel:** Direct 2D thread-block-to-grid mapping with global-memory access.
- **Tiled kernel:** Each thread block loads an expanded (Bx + 2r) x (By + 2r) tile into shared memory before computing, eliminating redundant global memory reads.

### Step 4 — MPI Domain Decomposition
Partition the global N x N grid into horizontal strips. Each rank owns (N/P) rows plus 2 ghost (halo) rows exchanged with neighbours after each time step.

### Step 5 — Full Hybrid Integration
Combine all three layers:
- MPI ranks each drive one GPU
- MPI_Isend/MPI_Irecv initiated immediately
- Interior rows computed on GPU (CUDA stream 1) while halo exchange runs concurrently
- Boundary rows updated on GPU (CUDA stream 2) after MPI_Waitall
- OpenMP parallelizes host-side halo buffer packing/unpacking

### Step 6 — Benchmarking and Analysis
- Strong scaling: fix N = 4096, vary P = 1, 2, 4, 8 ranks
- Weak scaling: fix per-rank grid size, grow total grid with P
- Roofline analysis: measure arithmetic intensity vs. achieved bandwidth
- Ablation: blocking vs. non-blocking MPI vs. full overlap with CUDA streams

---

## 7. Expected Outcomes

- A validated serial to OpenMP to CUDA to Hybrid progression, each verified against the analytical reference.
- Strong- and weak-scaling plots demonstrating speedup and parallel efficiency.
- A quantified performance gain from communication-computation overlap vs. naive blocking MPI.
- Achieved GFLOP/s benchmarked against a roofline estimate for the GPU hardware used.
- A research manuscript targetable to Scopus-indexed IEEE/Springer HPC venues.

---

## 8. Tentative Implementation Plan

| Phase | Tasks | Timeline |
|---|---|---|
| Phase 1 | Environment/repo setup; serial C/C++ stencil; analytical reference | Weeks 1-2 |
| Phase 2 | OpenMP CPU parallelization; scheduling policy comparison | Week 3 |
| Phase 3 | Baseline single-GPU CUDA kernel (global-memory mapping) | Weeks 3-4 |
| Phase 4 | MPI 1D strip decomposition; blocking halo exchange baseline | Weeks 4-5 |
| Phase 5 | Full Hybrid MPI+CUDA+OpenMP; shared-memory tiling; non-blocking CUDA streams | Weeks 5-7 |
| Phase 6 | Strong/weak scaling; roofline analysis; overlap ablation study | Weeks 7-8 |
| Phase 7 | Correctness validation; report writing; conference paper preparation | Weeks 8-9 |

---

## References (IEEE Format)

[1] Message Passing Interface Forum, "MPI: A Message-Passing Interface Standard, Version 4.0," 2021.  
[2] NVIDIA Corporation, "CUDA C++ Programming Guide," NVIDIA Developer Documentation, 2024.  
[3] OpenMP Architecture Review Board, "OpenMP Application Programming Interface Version 5.2," 2021.  
[4] S. Williams, A. Waterman, and D. Patterson, "Roofline: An Insightful Visual Performance Model for Multicore Architectures," *Communications of the ACM*, vol. 52, no. 4, 2009.  
[5] W. Gropp, T. Hoefler, R. Thakur, and E. Lusk, *Using Advanced MPI: Modern Features of the Message-Passing Interface*, MIT Press, 2014.
