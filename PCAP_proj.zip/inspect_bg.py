from pptx import Presentation

prs = Presentation("Stencil_MiniProject_Presentation.pptx")
slide = prs.slides[0]
bg = slide.background
if bg and bg.fill:
    print("Fill type:", bg.fill.type)
    if hasattr(bg.fill, "fore_color"):
        print("RGB:", bg.fill.fore_color.rgb)
