from pptx import Presentation

prs = Presentation("Stencil_MiniProject_Presentation_With_Graphs.pptx")
print(f"Slide width: {prs.slide_width.inches} in, height: {prs.slide_height.inches} in")
for i, slide in enumerate(prs.slides):
    title = ""
    for shape in slide.shapes:
        if shape.has_text_frame and shape.text_frame.text.strip():
            title = shape.text_frame.text.strip().split("\n")[0]
            break
    print(f"Slide {i+1}: {title} | Shapes: {len(slide.shapes)}")
