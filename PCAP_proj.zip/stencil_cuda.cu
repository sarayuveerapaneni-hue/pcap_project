/*
 * CUDA naive and shared-memory tiled 2D heat stencil.
 * The field remains on the device for all time steps.
 *
 *   nvcc -std=c++17 -O3 -arch=sm_86 stencil_cuda.cu -o stencil_cuda
 *   nvcc -std=c++17 -O3 -arch=sm_86 -DUSE_NAIVE stencil_cuda.cu -o stencil_cuda_naive
 *
 *   ./stencil_cuda N steps repeats csv [dump.csv]
 */

#include "stencil_common.hpp"
#include <cuda_runtime.h>

constexpr int TX = 16;
constexpr int TY = 16;
constexpr int SR = 1;

static void cuda_check(cudaError_t err, const char* op) {
    if (err != cudaSuccess)
        throw std::runtime_error(std::string(op) + ": " + cudaGetErrorString(err));
}
#define CUDA_CHECK(op) cuda_check((op), #op)

__global__ void stencil_naive_kernel(const double* src, double* dst, int N, double r) {
    const int j = blockIdx.x * blockDim.x + threadIdx.x;
    const int i = blockIdx.y * blockDim.y + threadIdx.y;
    if (i < 1 || i >= N - 1 || j < 1 || j >= N - 1) return;
    const int idx = i * N + j;
    dst[idx] = src[idx] + r * (
        src[(i + 1) * N + j] + src[(i - 1) * N + j] +
        src[i * N + j + 1] + src[i * N + j - 1] - 4.0 * src[idx]
    );
}

#define TILE_W (TX + 2 * SR)
#define TILE_H (TY + 2 * SR)

__global__ void stencil_tiled_kernel(const double* src, double* dst, int N, double r) {
    __shared__ double smem[TILE_H][TILE_W];
    const int gj = blockIdx.x * TX + threadIdx.x;
    const int gi = blockIdx.y * TY + threadIdx.y;
    const int lj = threadIdx.x + SR;
    const int li = threadIdx.y + SR;

    auto load = [&](int i, int j) -> double {
        if (i < 0 || j < 0 || i >= N || j >= N) return 0.0;
        return src[i * N + j];
    };

    smem[li][lj] = load(gi, gj);
    if (threadIdx.x < SR) smem[li][lj - SR] = load(gi, gj - SR);
    if (threadIdx.x >= TX - SR) smem[li][lj + SR] = load(gi, gj + SR);
    if (threadIdx.y < SR) smem[li - SR][lj] = load(gi - SR, gj);
    if (threadIdx.y >= TY - SR) smem[li + SR][lj] = load(gi + SR, gj);
    /* Corners are unused by the 5-point stencil. */
    __syncthreads();

    if (gi < 1 || gi >= N - 1 || gj < 1 || gj >= N - 1) return;
    dst[gi * N + gj] = smem[li][lj] + r * (
        smem[li + 1][lj] + smem[li - 1][lj] +
        smem[li][lj + 1] + smem[li][lj - 1] - 4.0 * smem[li][lj]
    );
}

int main(int argc, char* argv[]) {
    try {
        require_stable();
        const int N = (argc > 1) ? std::stoi(argv[1]) : DEFAULT_N;
        const int steps = (argc > 2) ? std::stoi(argv[2]) : DEFAULT_STEPS;
        const int repeats = (argc > 3) ? std::stoi(argv[3]) : 1;
        const std::string csv = (argc > 4) ? argv[4] : "results/raw_runs.csv";
        const std::string dump = (argc > 5) ? argv[5] : "";
        if (N < 4 || steps < 1) throw std::runtime_error("bad N/steps");

        int ndev = 0;
        CUDA_CHECK(cudaGetDeviceCount(&ndev));
        if (ndev < 1) throw std::runtime_error("No CUDA GPU");
        CUDA_CHECK(cudaSetDevice(0));
        cudaDeviceProp prop{};
        CUDA_CHECK(cudaGetDeviceProperties(&prop, 0));

#ifdef USE_NAIVE
        const std::string impl = "cuda_naive";
#else
        const std::string impl = "cuda_tiled";
#endif

        Grid host(N);
        initialise_sine(host);
        const size_t bytes = static_cast<size_t>(N) * N * sizeof(double);
        double *d_src = nullptr, *d_dst = nullptr;
        CUDA_CHECK(cudaMalloc(&d_src, bytes));
        CUDA_CHECK(cudaMalloc(&d_dst, bytes));

        dim3 block(TX, TY);
        dim3 grid((N + TX - 1) / TX, (N + TY - 1) / TY);

        ErrorStats last_err{};
        double last_runtime = 0.0;
        Grid last(N);

        for (int rep = 0; rep < repeats; ++rep) {
            CUDA_CHECK(cudaMemcpy(d_src, host.ptr(), bytes, cudaMemcpyHostToDevice));
            CUDA_CHECK(cudaMemcpy(d_dst, host.ptr(), bytes, cudaMemcpyHostToDevice));

            cudaEvent_t ev0, ev1;
            CUDA_CHECK(cudaEventCreate(&ev0));
            CUDA_CHECK(cudaEventCreate(&ev1));
            CUDA_CHECK(cudaEventRecord(ev0));
            for (int s = 0; s < steps; ++s) {
#ifdef USE_NAIVE
                stencil_naive_kernel<<<grid, block>>>(d_src, d_dst, N, STABILITY_R);
#else
                stencil_tiled_kernel<<<grid, block>>>(d_src, d_dst, N, STABILITY_R);
#endif
                CUDA_CHECK(cudaGetLastError());
                std::swap(d_src, d_dst);
            }
            CUDA_CHECK(cudaEventRecord(ev1));
            CUDA_CHECK(cudaEventSynchronize(ev1));
            float ms = 0.0f;
            CUDA_CHECK(cudaEventElapsedTime(&ms, ev0, ev1));
            last_runtime = ms / 1000.0;
            CUDA_CHECK(cudaEventDestroy(ev0));
            CUDA_CHECK(cudaEventDestroy(ev1));

            CUDA_CHECK(cudaMemcpy(last.ptr(), d_src, bytes, cudaMemcpyDeviceToHost));
            last_err = compute_errors(last, steps);
            append_benchmark_row(csv, impl, N, steps, prop.multiProcessorCount, rep,
                                 last_runtime, compute_gflops(N, steps, last_runtime),
                                 last_err, 0.0);
        }

        print_run(impl, prop.multiProcessorCount, N, steps, last_runtime,
                  compute_gflops(N, steps, last_runtime), last_err, 0.0);
        std::cout << "gpu_name=" << prop.name
                  << "\nsm_count=" << prop.multiProcessorCount
                  << "\nkernel_resident_on_device=1\n";
        if (!dump.empty()) save_grid_csv(dump, last);
        CUDA_CHECK(cudaFree(d_src));
        CUDA_CHECK(cudaFree(d_dst));
        return (last_err.max_abs_discrete < 1e-9) ? 0 : 2;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
