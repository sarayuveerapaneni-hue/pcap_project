#pragma once

#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef USE_OPENMP
#include <omp.h>
#endif

/*
 * 2D heat equation (Dirichlet) on the unit square, FTCS 5-point stencil.
 *
 * Domain: [0, L] x [0, L], L = 1
 * Grid: N x N nodes, including boundaries
 * Spacing: h = L / (N-1)
 * Coordinates: x_j = j * h, y_i = i * h, i,j = 0..N-1
 *
 * PDE: u_t = ALPHA * (u_xx + u_yy)
 * BC:  u = 0 on the boundary
 * IC:  u(x,y,0) = sin(pi x / L) * sin(pi y / L)
 *
 * Continuous first-mode solution:
 *   u(x,y,t) = sin(pi x/L) sin(pi y/L) exp(-2 pi^2 ALPHA t / L^2)
 *
 * Discrete eigenmode of the 5-point Laplacian (exact for this IC under FTCS):
 *   G = 1 + 4 r (cos(pi h / L) - 1)
 *   u_ij^n = sin(pi x_j/L) sin(pi y_i/L) * G^n
 *
 * Stability: r = ALPHA * dt / h^2 <= 1/4.  We fix r = 0.20.
 *
 * FLOP convention: each interior update is counted as 8 floating-point
 * operations matching the implemented expression
 *   u + r * (n + s + e + w - 4*u)
 * (4 adds of neighbours, 1 multiply by 4, 1 subtract, 1 multiply by r, 1 add).
 *
 * Roofline bytes (compulsory, no cache, write-allocate ignored):
 *   5 double reads + 1 double write = 48 bytes per interior point per step.
 * Arithmetic intensity = 8/48 = 1/6 FLOP/byte.
 */

constexpr double ALPHA = 1.0;
constexpr double L_DOMAIN = 1.0;
constexpr double STABILITY_R = 0.20;
constexpr double PI = 3.14159265358979323846;

constexpr int DEFAULT_N = 256;
constexpr int DEFAULT_STEPS = 200;
constexpr int DEFAULT_REPEATS = 5;

inline void require_stable() {
    if (STABILITY_R > 0.25 + 1e-15) {
        throw std::runtime_error("FTCS unstable: r must be <= 0.25");
    }
}

inline double grid_h(int N) {
    if (N < 4) throw std::runtime_error("N >= 4 required");
    return L_DOMAIN / static_cast<double>(N - 1);
}

inline double time_step_dt(int N) {
    const double h = grid_h(N);
    return STABILITY_R * h * h / ALPHA;
}

inline double coord(int idx, int N) {
    return static_cast<double>(idx) * grid_h(N);
}

inline double mode_xy(int i, int j, int N) {
    const double s = std::sin(PI * coord(j, N) / L_DOMAIN)
                   * std::sin(PI * coord(i, N) / L_DOMAIN);
    return s;
}

inline double amplification_G(int N) {
    const double h = grid_h(N);
    return 1.0 + 4.0 * STABILITY_R * (std::cos(PI * h / L_DOMAIN) - 1.0);
}

inline double analytical_continuous(int i, int j, int N, double t) {
    return mode_xy(i, j, N) * std::exp(-2.0 * PI * PI * ALPHA * t / (L_DOMAIN * L_DOMAIN));
}

inline double analytical_discrete(int i, int j, int N, int steps) {
    return mode_xy(i, j, N) * std::pow(amplification_G(N), static_cast<double>(steps));
}

struct Grid {
    int n = 0;
    std::vector<double> data;

    Grid() = default;
    explicit Grid(int N, double fill = 0.0) : n(N), data(static_cast<size_t>(N) * N, fill) {}

    inline double& at(int i, int j) { return data[static_cast<size_t>(i) * n + j]; }
    inline double at(int i, int j) const { return data[static_cast<size_t>(i) * n + j]; }
    double* ptr() { return data.data(); }
    const double* ptr() const { return data.data(); }
};

inline void initialise_sine(Grid& g) {
    const int N = g.n;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (i == 0 || j == 0 || i == N - 1 || j == N - 1)
                g.at(i, j) = 0.0;
            else
                g.at(i, j) = mode_xy(i, j, N);
        }
    }
}

struct ErrorStats {
    double rms_continuous = 0.0;
    double rel_l2_continuous = 0.0;
    double max_abs_continuous = 0.0;
    double rms_discrete = 0.0;
    double rel_l2_discrete = 0.0;
    double max_abs_discrete = 0.0;
};

inline ErrorStats compute_errors(const Grid& g, int steps) {
    const int N = g.n;
    const double t = steps * time_step_dt(N);
    double sum_c = 0.0, sum_d = 0.0, sum_ref_c = 0.0, sum_ref_d = 0.0;
    double max_c = 0.0, max_d = 0.0;
    long long count = 0;

    for (int i = 1; i < N - 1; ++i) {
        for (int j = 1; j < N - 1; ++j) {
            const double u = g.at(i, j);
            const double uc = analytical_continuous(i, j, N, t);
            const double ud = analytical_discrete(i, j, N, steps);
            const double dc = u - uc;
            const double dd = u - ud;
            sum_c += dc * dc;
            sum_d += dd * dd;
            sum_ref_c += uc * uc;
            sum_ref_d += ud * ud;
            max_c = std::max(max_c, std::abs(dc));
            max_d = std::max(max_d, std::abs(dd));
            ++count;
        }
    }

    ErrorStats e;
    e.rms_continuous = std::sqrt(sum_c / static_cast<double>(count));
    e.rms_discrete = std::sqrt(sum_d / static_cast<double>(count));
    e.rel_l2_continuous = std::sqrt(sum_c / std::max(sum_ref_c, 1e-300));
    e.rel_l2_discrete = std::sqrt(sum_d / std::max(sum_ref_d, 1e-300));
    e.max_abs_continuous = max_c;
    e.max_abs_discrete = max_d;
    return e;
}

inline double max_abs_diff(const Grid& a, const Grid& b) {
    if (a.n != b.n) throw std::runtime_error("grid size mismatch");
    double m = 0.0;
    for (size_t k = 0; k < a.data.size(); ++k)
        m = std::max(m, std::abs(a.data[k] - b.data[k]));
    return m;
}

inline double compute_gflops(int N, int steps, double seconds) {
    const double interior = static_cast<double>(N - 2) * static_cast<double>(N - 2);
    const double flops = interior * 8.0 * static_cast<double>(steps);
    return flops / seconds / 1.0e9;
}

inline void save_grid_csv(const std::string& path, const Grid& g) {
    std::ofstream out(path);
    if (!out) throw std::runtime_error("Cannot open " + path);
    out << std::scientific << std::setprecision(16);
    const int N = g.n;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (j) out << ",";
            out << g.at(i, j);
        }
        out << "\n";
    }
}

inline void append_csv_header_if_needed(const std::string& path) {
    std::ifstream probe(path);
    const bool empty = !probe.good() || probe.peek() == std::char_traits<char>::eof();
    if (!empty) return;
    std::ofstream out(path, std::ios::app);
    out << "implementation,N,steps,workers,repeat_index,runtime_seconds,"
           "gflops,rms_continuous,rel_l2_continuous,max_abs_continuous,"
           "rms_discrete,rel_l2_discrete,max_abs_discrete,"
           "max_abs_vs_sequential,h,dt,r,alpha,L\n";
}

inline void append_benchmark_row(
    const std::string& path,
    const std::string& impl,
    int N, int steps, int workers, int repeat_index,
    double runtime, double gflops, const ErrorStats& e,
    double max_abs_vs_seq
) {
    append_csv_header_if_needed(path);
    std::ofstream out(path, std::ios::app);
    if (!out) throw std::runtime_error("Cannot open " + path);
    out << std::scientific << std::setprecision(10);
    out << impl << "," << N << "," << steps << "," << workers << ","
        << repeat_index << "," << runtime << "," << gflops << ","
        << e.rms_continuous << "," << e.rel_l2_continuous << "," << e.max_abs_continuous << ","
        << e.rms_discrete << "," << e.rel_l2_discrete << "," << e.max_abs_discrete << ","
        << max_abs_vs_seq << ","
        << grid_h(N) << "," << time_step_dt(N) << "," << STABILITY_R << ","
        << ALPHA << "," << L_DOMAIN << "\n";
}

inline void print_run(
    const std::string& impl, int workers, int N, int steps,
    double runtime, double gflops, const ErrorStats& e,
    double max_abs_vs_seq
) {
    std::cout << std::scientific << std::setprecision(10);
    std::cout << "implementation=" << impl << "\n"
              << "workers=" << workers << "\n"
              << "N=" << N << "\n"
              << "steps=" << steps << "\n"
              << "h=" << grid_h(N) << "\n"
              << "dt=" << time_step_dt(N) << "\n"
              << "r=" << STABILITY_R << "\n"
              << "alpha=" << ALPHA << "\n"
              << "L=" << L_DOMAIN << "\n"
              << "G_discrete=" << amplification_G(N) << "\n"
              << "runtime_seconds=" << runtime << "\n"
              << "gflops=" << gflops << "\n"
              << "flop_convention=8_per_interior_update\n"
              << "rms_continuous=" << e.rms_continuous << "\n"
              << "rel_l2_continuous=" << e.rel_l2_continuous << "\n"
              << "max_abs_continuous=" << e.max_abs_continuous << "\n"
              << "rms_discrete=" << e.rms_discrete << "\n"
              << "rel_l2_discrete=" << e.rel_l2_discrete << "\n"
              << "max_abs_discrete=" << e.max_abs_discrete << "\n"
              << "max_abs_vs_sequential=" << max_abs_vs_seq << "\n"
              << "tolerance_vs_discrete=1e-9\n"
              << "tolerance_vs_sequential=1e-9\n";
}

inline void stencil_update_rows(
    const Grid& src, Grid& dst, int row_begin, int row_end
) {
    const int N = src.n;
    const double r = STABILITY_R;
#ifdef USE_OPENMP
    #pragma omp parallel for schedule(runtime)
#endif
    for (int i = row_begin; i < row_end; ++i) {
        if (i <= 0 || i >= N - 1) continue;
        for (int j = 1; j < N - 1; ++j) {
            dst.at(i, j) = src.at(i, j) + r * (
                src.at(i + 1, j) + src.at(i - 1, j) +
                src.at(i, j + 1) + src.at(i, j - 1) -
                4.0 * src.at(i, j)
            );
        }
    }
}
